pip3 install --no-index zipp-3.15.0-py3-none-any.whl
pip3 install --no-index typing_extensions-4.7.1-py3-none-any.whl
pip3 install --no-index importlib_metadata-6.7.0-py3-none-any.whl
pip3 install --no-index itsdangerous-2.1.2-py3-none-any.whl
pip3 install --no-index MarkupSafe-2.1.5-cp37-cp37m-manylinux_2_17_x86_64.manylinux2014_x86_64.whl
pip3 install --no-index Werkzeug-2.2.3-py3-none-any.whl
pip3 install --no-index click-8.1.8-py3-none-any.whl
pip3 install --no-index jinja2-3.1.6-py3-none-any.whl
pip3 install --no-index Flask-2.1.1-py3-none-any.whl
pip3 install --no-index Flask_Cors-3.0.10-py2.py3-none-any.whl
pip3 install --no-index psutil-5.8.0-cp37-cp37m-manylinux2010_x86_64.whl

