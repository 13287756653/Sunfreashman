#!/bin/bash

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # 无色

echo -e "${YELLOW}========== 开始安装 .whl 依赖包 ==========${NC}"

while IFS= read -r line || [[ -n "$line" ]]; do
    if [[ $line == pip3* ]]; then
        pkg=$(echo $line | awk '{print $3}')
        echo -e "${YELLOW}---------- 正在安装: $pkg ----------${NC}"
        echo -e "${YELLOW}命令: $line${NC}"
        if $line; then
            echo -e "${GREEN}✅ 已安装: $pkg${NC}"
        else
            echo -e "${RED}❌ 安装 $pkg 失败${NC}"
            exit 1
        fi
        echo -e "${YELLOW}------------------------------------${NC}\n"
    fi
done < readme.txt

echo -e "${YELLOW}========== .whl 依赖包安装完成 ==========${NC}\n"
echo -e "${GREEN}🎉 所有依赖安装完成！${NC}"
