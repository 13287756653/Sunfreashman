#!/bin/bash

# 设置IPV6 radvd
config_file="/etc/radvd.conf"
first_interface=$(ip -o link show | grep -v "lo\|vir\|tun\|tap\|bond\|team\|dummy\|docker" | awk -F': ' '{print $2}' | head -n 1)
SPACES="    "
SPACESA="        "
IPV6NET=$(ip -6 addr show | grep -Po 'inet6 \K(?!(fe80|::1))[0-9a-f:]+/[0-9]+')
sed -i '5,$d' "$config_file"
echo "interface $first_interface" >> $config_file
echo "{" >> $config_file
echo -e "$SPACES AdvManagedFlag on;" >> "$config_file"
echo -e "$SPACES AdvSendAdvert on;" >> "$config_file"
echo -e "$SPACES AdvOtherConfigFlag on;" >> "$config_file"
echo -e "$SPACES AdvLinkMTU 1480;" >> "$config_file"
echo -e "$SPACES MinRtrAdvInterval 30;" >> "$config_file"
echo -e "$SPACES MaxRtrAdvInterval 100;" >> "$config_file"
echo -e "$SPACES prefix $IPV6NET" >> "$config_file"
echo -e "$SPACES {" >> "$config_file"
echo -e "$SPACESA AdvOnLink on;" >> "$config_file"
echo -e "$SPACESA AdvAutonomous on;" >> "$config_file"
echo -e "$SPACESA AdvRouterAddr on;" >> "$config_file"
echo -e "$SPACES };" >> "$config_file"
echo -e "};" >> "$config_file"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
NC='\033[0m' # 恢复默认颜色

# 图形符号
CHECKMARK="✓"
CROSSMARK="✗"
INFO="i"
WARNING="!"
ARROW="->"

# 分隔线
BORDER="=================================================================="

# 函数：打印带颜色的标题
print_title() {
    echo -e "${BLUE}${BORDER}${NC}"
    echo -e "${BLUE}${1}${NC}"
    echo -e "${BLUE}${BORDER}${NC}"
    sleep 1
}

# 函数：打印成功信息
print_success() {
    echo -e "${GREEN}${CHECKMARK} ${1}${NC}"
    sleep 1
}

# 函数：打印错误信息
print_error() {
    echo -e "${RED}${CROSSMARK} ${1}${NC}"
    sleep 1
}

# 函数：打印提示信息
print_info() {
    echo -e "${YELLOW}${INFO} ${1}${NC}"
    sleep 1
}

# 函数：打印警告信息
print_warning() {
    echo -e "${MAGENTA}${WARNING} ${1}${NC}"
    sleep 1
}

# 函数：打印带符号的步骤
print_step() {
    echo -e "${BLUE}${ARROW} ${1}${NC}"
    sleep 1
}

# 动态获取第一个非虚拟网络接口名
INTERFACE=$(ip -o link show | grep -v "lo\|vir\|tun\|tap\|bond\|team\|dummy\|docker" | awk -F': ' '{print $2}' | head -n 1)

# 检查是否成功获取接口名
if [ -z "$INTERFACE" ]; then
    echo -e "${RED}错误: 无法获取有效的网络接口名！${NC}"
    exit 1
fi

# 标准配置参数（键为参数名，值为标准值，不包含分号）
declare -A STANDARD_PARAMS=(
    ["interface"]="$INTERFACE"
    ["AdvManagedFlag"]="on"
    ["AdvSendAdvert"]="on"
    ["AdvOtherConfigFlag"]="on"
    ["AdvLinkMTU"]="1480"
    ["MinRtrAdvInterval"]="30"
    ["MaxRtrAdvInterval"]="100"
    ["prefix"]="2025:db8::10/64"
    ["AdvOnLink"]="on"
    ["AdvAutonomous"]="on"
    ["AdvRouterAddr"]="on"
)

# prefix块参数
PREFIX_PARAMS=("AdvOnLink" "AdvAutonomous" "AdvRouterAddr")

# 配置文件路径
CONFIG_FILE="/etc/radvd.conf"
# 错误计数器
ERROR_COUNT=0

# 打印校验开始信息
print_title "RADVD配置精确校验工具"
echo -e "${YELLOW}i 使用网络接口: ${GREEN}$INTERFACE${NC}"
print_step "正在校验配置参数（仅对比值，忽略所有格式）..."

# 读取配置文件内容
if [ ! -f "$CONFIG_FILE" ]; then
    print_error "配置文件 '$CONFIG_FILE' 不存在"
    exit 1
fi
config_content=$(cat "$CONFIG_FILE")

# 提取并校验interface名称
interface_name=$(echo "$config_content" | grep -E "^[[:space:]]*interface[[:space:]]+[a-zA-Z0-9_.-]+" | head -1 | awk '{print $2}')
print_info "校验 interface 名称..."
if [ "$interface_name" = "${STANDARD_PARAMS["interface"]}" ]; then
    print_success "interface 名称正确: ${GREEN}$interface_name${NC}"
else
    ERROR_COUNT=$((ERROR_COUNT + 1))
    print_error "interface 名称错误"
    echo -e "  ${YELLOW}文件值:${NC} ${RED}$interface_name${NC}"
    echo -e "  ${YELLOW}标准值:${NC} ${GREEN}${STANDARD_PARAMS["interface"]}${NC}"
fi

# 校验主块参数（匹配"参数 值;"格式）
print_info "校验主块参数（仅对比值）..."
for param in "AdvManagedFlag" "AdvSendAdvert" "AdvOtherConfigFlag" "AdvLinkMTU" "MinRtrAdvInterval" "MaxRtrAdvInterval"; do
    # 正则表达式匹配参数行（允许任意空格和缩进）
    param_line=$(echo "$config_content" | grep -E "^[[:space:]]*$param[[:space:]]+[^;]+;" | head -1)

    if [ -n "$param_line" ]; then
        # 提取参数值并去除所有空格和分号
        param_value=$(echo "$param_line" | sed -E "s/^[[:space:]]*$param[[:space:]]+//" | sed -E "s/;.*$//" | tr -d '[:space:]')
        std_value=${STANDARD_PARAMS[$param]}

        if [ "$param_value" = "$std_value" ]; then
            print_success "参数 '$param' 正确: ${GREEN}$std_value${NC}"
        else
            ERROR_COUNT=$((ERROR_COUNT + 1))
            print_error "参数 '$param' 错误"
            echo -e "  ${YELLOW}文件值:${NC} ${RED}$param_value${NC}"
            echo -e "  ${YELLOW}标准值:${NC} ${GREEN}$std_value${NC}"
        fi
    else
        ERROR_COUNT=$((ERROR_COUNT + 1))
        print_error "未找到参数 '$param'"
        echo -e "  ${YELLOW}标准值:${NC} ${GREEN}${STANDARD_PARAMS[$param]}${NC}"
    fi
done

# 校验prefix地址（忽略分号）
print_info "校验prefix地址（忽略末尾分号）..."
prefix_regex="^[[:space:]]*prefix[[:space:]]+([0-9a-f:]+/[0-9]+)"
prefix_line=$(echo "$config_content" | grep -E "$prefix_regex" | head -1)

if [ -n "$prefix_line" ]; then
    # 提取prefix地址并去除所有空格
    prefix_addr=$(echo "$prefix_line" | sed -E "s/^[[:space:]]*prefix[[:space:]]+//" | tr -d '[:space:]')
    std_prefix=${STANDARD_PARAMS["prefix"]}

    if [ "$prefix_addr" = "$std_prefix" ]; then
        print_success "prefix 地址正确: ${GREEN}$std_prefix${NC}"
    else
        ERROR_COUNT=$((ERROR_COUNT + 1))
        print_error "prefix 地址错误"
        echo -e "  ${YELLOW}文件值:${NC} ${RED}$prefix_addr${NC}"
        echo -e "  ${YELLOW}标准值:${NC} ${GREEN}$std_prefix${NC}"
    fi
else
    ERROR_COUNT=$((ERROR_COUNT + 1))
    print_error "未找到prefix配置"
    echo -e "  ${YELLOW}标准值:${NC} ${GREEN}$std_prefix${NC}"
fi

# 校验prefix块内参数（使用改进的方法）
print_info "校验prefix块内参数..."

# 转义prefix地址中的特殊字符
escaped_prefix=$(echo "$std_prefix" | sed 's/[\/&]/\\&/g')

# 更健壮的prefix块提取方法
# 1. 找到prefix行的行号
prefix_line_num=$(echo "$config_content" | grep -n -E "^[[:space:]]*prefix[[:space:]]+$escaped_prefix[[:space:]]*$" | cut -d: -f1)

if [ -n "$prefix_line_num" ]; then
    # 2. 找到对应的起始括号行号
    start_brace_line_num=$(echo "$config_content" | tail -n +$prefix_line_num | grep -n -E "^[[:space:]]*\{$" | head -1 | cut -d: -f1)
    
    if [ -n "$start_brace_line_num" ]; then
        # 计算实际起始括号行号
        start_brace_line_num=$((prefix_line_num + start_brace_line_num - 1))
        
        # 3. 使用栈方法找到匹配的结束括号
        brace_count=1
        current_line=$((start_brace_line_num + 1))
        end_brace_line=""
        
        while IFS= read -r line; do
            # 计算当前行的括号平衡
            open_braces=$(echo "$line" | grep -o "{" | wc -l)
            close_braces=$(echo "$line" | grep -o "}" | wc -l)
            brace_count=$((brace_count + open_braces - close_braces))
            
            if [ $brace_count -eq 0 ]; then
                end_brace_line=$current_line
                break
            fi
            
            current_line=$((current_line + 1))
        done < <(echo "$config_content" | tail -n +$current_line)
        
        if [ -n "$end_brace_line" ]; then
            # 提取prefix块内容
            prefix_block=$(echo "$config_content" | sed -n "${start_brace_line_num},${end_brace_line}p" | tr -d '[:space:]')
            
            # 校验每个prefix子参数
            param_found=0
            for param in "${PREFIX_PARAMS[@]}"; do
                if echo "$prefix_block" | grep -q "$paramon;"; then
                    print_success "prefix 内参数 '$param' 正确"
                    param_found=$((param_found + 1))
                else
                    ERROR_COUNT=$((ERROR_COUNT + 1))
                    print_error "prefix 内参数 '$param' 错误"
                    echo -e "  ${YELLOW}标准值:${NC} ${GREEN}$param on${NC}"
                fi
            done
            
            # 如果找到所有参数，认为块存在
            if [ $param_found -eq ${#PREFIX_PARAMS[@]} ]; then
                print_success "prefix 块配置完整"
            else
                ERROR_COUNT=$((ERROR_COUNT + 1))
                print_error "prefix 块参数不完整"
            fi
        else
            ERROR_COUNT=$((ERROR_COUNT + 1))
            print_error "无法找到匹配的结束括号"
        fi
    else
        ERROR_COUNT=$((ERROR_COUNT + 1))
        print_error "未找到prefix块的起始括号"
    fi
else
    ERROR_COUNT=$((ERROR_COUNT + 1))
    print_error "未找到prefix配置行"
fi

# 输出结果
print_title "配置校验总结"
if [ $ERROR_COUNT -eq 0 ]; then
    print_success "RADVD配置完全符合标准！所有参数均正确。"
else
    print_error "RADVD配置存在 $ERROR_COUNT 处错误！"
    print_warning "请根据上面的提示修正配置文件"
fi
