#!/bin/bash

# 错误处理函数
handle_error() {
    local error_message="$1"
    echo -e "${RED}Error: $1${NC}" >&2
    exit 1
}

# 获取当前主机的 IPv6 和 IPv4 地址相关信息
ipv6=$(ip -6 addr show | grep -Po 'inet6 \K(?!(fe80|::1))[0-9a-f:]+/[0-9]+' | sed -e 's/\/[0-9]*//')
if [ -z "$ipv6" ]; then
    handle_error "Failed to get IPv6 address."
fi
network_ipv6=$(ip -6 addr show | grep -Po 'inet6 \K(?!(fe80|::1))[0-9a-f:]+/[0-9]+' | sed -E 's/^([0-9a-f]+:[0-9a-f]+):.+?(\/[0-9]+)$/\1::\2/')
if [ -z "$network_ipv6" ]; then
    handle_error "Failed to get IPv6 network address."
fi
network_ipv6_ip=$(ip -6 addr show | grep -Po 'inet6 \K(?!(fe80|::1))[0-9a-f:]+/[0-9]+' | sed -E 's|^([0-9a-f]+:[0-9a-f]+):.+?/[0-9]+$|\1::|')
if [ -z "$network_ipv6_ip" ]; then
    handle_error "Failed to get IPv6 network IP."
fi

network_ipv4=$(ip -4 -o addr show | grep -E '192\.168\.3\.\S+' | awk '{print $4}' | cut -d/ -f1)
if [ -z "$network_ipv4" ]; then
    handle_error "Failed to get IPv4 address."
fi
network_ipv4_a=$(echo "$network_ipv4" | awk -F'.' '{print $1"."$2"."$3".0"}')

# 定义缩进空格
SPACES="    "

# IPV6 配置部分
config_file_IPV6="/etc/dhcp/dhcpd6.conf"
# 清空配置文件第 6 行及以后的内容
sed -i '6,$d' "$config_file_IPV6" || handle_error "Failed to modify $config_file_IPV6."

# 使用 Here Document 写入配置内容
cat << EOF >> "$config_file_IPV6"
default-lease-time 2592000;
preferred-lifetime 604800;
option dhcp-renewal-time 3600;
option dhcp-rebinding-time 7200;
allow leasequery;
option dhcp6.name-servers $ipv6;
option dhcp6.domain-search "dhcpserver";
option dhcp6.preference 255;
option dhcp6.rapid-commit;
option dhcp6.info-refresh-time 21600;
dhcpv6-lease-file-name "/var/lib/dhcpd/dhcpd6.leases";

# 参考配置风格的选项定义
option dhcp6.bootfile-url code 59 = string;
option dhcp6.client-arch-type code 61 = array of unsigned integer 16;

subnet6 $network_ipv6 {
${SPACES}range6 ${network_ipv6_ip}50 ${network_ipv6_ip}200;

${SPACES}# 根据客户端架构类型选择不同的启动文件
${SPACES}if option dhcp6.client-arch-type = 0 {
${SPACES}${SPACES}option dhcp6.bootfile-url "tftp://[${ipv6}]/x86/BOOTX64.EFI";
${SPACES}} else if option dhcp6.client-arch-type = 12 {
${SPACES}${SPACES}option dhcp6.bootfile-url "tftp://[${ipv6}]/arm64/BOOTAA64.EFI";
${SPACES}} else {
${SPACES}${SPACES}# 默认为x86_64架构
${SPACES}${SPACES}option dhcp6.bootfile-url "tftp://[${ipv6}]/x86/BOOTX64.EFI";
${SPACES}}
}
EOF

# IPV4 配置部分
config_file_IPV4="/etc/dhcp/dhcpd.conf"
# 清空配置文件第 6 行及以后的内容
sed -i '6,$d' "$config_file_IPV4"

# 使用 Here Document 写入配置内容
cat << EOF >> "$config_file_IPV4"

ddns-update-style interim;
allow booting;
allow bootp;
ignore client-updates;

set vendorclass = option vendor-class-identifier;
# 引用模块判断裸机类型是x86还是arm
option pxe-system-type code 93 = unsigned integer 16;
# 配置要分配的地址段及netmask, 需要修改为自己的网段
subnet 192.168.3.0 netmask 255.255.255.0 {
${SPACES}# 配置网关，如dhcp有问题，注意网关的配置
${SPACES}option routers 192.168.3.1;
${SPACES}# 配置netmask
${SPACES}option subnet-mask 255.255.255.0;
${SPACES}# 分配的ip范围
${SPACES}range dynamic-bootp 192.168.3.50 192.168.3.200;
${SPACES}# 缺省租约时间
${SPACES}option domain-name "example.com";
${SPACES}option domain-name-servers 8.8.8.8;
${SPACES}default-lease-time 7200;
${SPACES}# 最大租约时间
${SPACES}max-lease-time 14400;
${SPACES}# 指定引导装机的ip
${SPACES}next-server 192.168.3.10;
${SPACES}### 华为ARM ###
${SPACES}class "HW-client" {
${SPACES}${SPACES}match if substring (option vendor-class-identifier, 0, 9) = "HW-Client";
${SPACES}${SPACES}filename "arm/BOOTAA64.EFI";
${SPACES}}
${SPACES}### 通用ARM ###
${SPACES}#class "pxeclients" {
${SPACES}#    match if substring (option vendor-class-identifier, 0, 9) = "PXEClient";
${SPACES}#    filename "arm/BOOTAA64.EFI";
${SPACES}#}
${SPACES}class "pxeclients" {
${SPACES}${SPACES}match if substring (option vendor-class-identifier, 0, 9) = "PXEClient";
${SPACES}${SPACES}# x86服务器引导
${SPACES}${SPACES}if option pxe-system-type = 00:07 or option pxe-system-type = 00:09 {
${SPACES}${SPACES}${SPACES}filename "x86/BOOTX64.EFI";
${SPACES}${SPACES}}
${SPACES}${SPACES}# arm服务器引导
${SPACES}${SPACES}else if option pxe-system-type = 00:0b {
${SPACES}${SPACES}${SPACES}filename "arm/grubaa64.efi";
${SPACES}${SPACES}}
${SPACES}${SPACES}else {
${SPACES}${SPACES}${SPACES}filename "pxelinux.0";
${SPACES}${SPACES}}
${SPACES}}
}
EOF

echo "配置文件已更新成功！"

# ====== 网络重启与检测 ======
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

echo -e "${YELLOW}正在检测主用网卡...${NC}"
iface=$(ip route | awk '/default/ {print $5; exit}')
if [ -z "$iface" ]; then
    handle_error "未检测到默认网关对应的网卡，无法重启网络。"
fi

echo -e "${YELLOW}检测到主用网卡: $iface${NC}"

# 先用 nmcli 关闭/开启网卡
echo -e "${YELLOW}使用 nmcli 关闭网卡 $iface...${NC}"
nmcli device disconnect "$iface" || handle_error "nmcli 关闭网卡 $iface 失败"
sleep 2
echo -e "${YELLOW}使用 nmcli 启动网卡 $iface...${NC}"
nmcli device connect "$iface" || handle_error "nmcli 启动网卡 $iface 失败"
sleep 2

# 检查是否只有一个 192.168.3.10 的 IPv4 地址
ipv4_count=$(ip -4 addr show dev "$iface" | grep -c 'inet 192\.168\.3\.10/')
if [ "$ipv4_count" -ne 1 ]; then
    echo -e "${YELLOW}检测到 $iface 存在多个 IPv4 地址，尝试使用 ifdown/ifup 重启...${NC}"
    ifdown "$iface" || handle_error "ifdown $iface 失败"
    sleep 2
    ifup "$iface" || handle_error "ifup $iface 失败"
    sleep 2
    ipv4_count=$(ip -4 addr show dev "$iface" | grep -c 'inet 192\.168\.3\.10/')
    if [ "$ipv4_count" -ne 1 ]; then
        handle_error "网卡 $iface 下存在多个 IPv4 地址，脚本终止。"
    fi
fi

echo -e "${GREEN}网卡 $iface 启动成功，且仅有一个 192.168.3.10 的 IPv4 地址！${NC}"
