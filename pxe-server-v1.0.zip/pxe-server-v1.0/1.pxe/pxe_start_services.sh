#!/bin/bash

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # 恢复默认颜色

log() {
    echo -e "${BLUE}[$(date '+%F %T')] $1${NC}"
}
log_success() {
    echo -e "${GREEN}[$(date '+%F %T')] $1${NC}"
}
log_warn() {
    echo -e "${YELLOW}[$(date '+%F %T')] $1${NC}"
}
log_error() {
    echo -e "${RED}[$(date '+%F %T')] $1${NC}"
}

# 错误处理
handle_error() {
    log_error "错误: $1"
    exit 1
}

# 关闭防火墙
disable_firewall() {
    log "正在关闭防火墙..."
    if command -v systemctl &>/dev/null; then
        systemctl stop firewalld || log_warn "firewalld 停止失败或已停止"
        systemctl disable firewalld || log_warn "firewalld 禁用失败或已禁用"
        log_success "防火墙已关闭并禁用开机自启"
    else
        log_warn "systemctl 不存在，跳过防火墙关闭"
    fi
}

# 关闭SELinux
disable_selinux() {
    log "正在检查并临时关闭SELinux..."
    if command -v getenforce &>/dev/null; then
        selinux_status=$(getenforce)
        case "$selinux_status" in
            "Enforcing")
                setenforce 0 && log_success "SELinux 已临时关闭" || log_warn "setenforce 0 失败"
                ;;
            "Permissive")
                log_warn "SELinux 已处于 Permissive"
                ;;
            "Disabled")
                log_warn "SELinux 已禁用"
                ;;
            *)
                log_warn "未知 SELinux 状态: $selinux_status"
                ;;
        esac
    else
        log_warn "getenforce 不存在，SELinux 可能未安装"
    fi
}

# # 断开并重连所有物理网卡
# reset_interfaces() {
#     available_interfaces=$(ip -o link show | grep -v "lo\|vir\|tun\|tap\|bond\|team\|dummy\|docker" | awk -F': ' '{print $2}')
#     for iface in $available_interfaces; do
#         log "断开 $iface"
#         nmcli dev disconnect "$iface" || log_warn "断开 $iface 失败"
#         # 获取连接名
#         con_name=$(nmcli -g NAME,DEVICE con show --active | grep ":$iface" | cut -d: -f1)
#         if [ -n "$con_name" ]; then
#             log "重连 $con_name ($iface)"
#             nmcli con up id "$con_name" || log_warn "重连 $con_name 失败"
#         else
#             log_warn "$iface 没有找到对应的连接名"
#         fi
#     done
#     if systemctl list-unit-files | grep -q network.service; then
#         systemctl restart network || log_warn "重启 network 失败"
#     fi
# }

# 启动服务
start_services() {
    local services=("tftp" "dhcpd" "httpd" "xinetd" "dhcpd6" "radvd")
    for service in "${services[@]}"; do
        if systemctl list-unit-files | grep -q "^$service"; then
            log "设置 $service 开机自启"
            systemctl enable "$service" || log_warn "$service enable 失败"
            log "启动 $service"
            systemctl start "$service" || log_warn "$service 启动失败"
            status=$(systemctl is-active "$service")
            if [ "$status" = "active" ]; then
                log_success "$service 已启动"
            else
                log_warn "$service 状态异常: $status"
            fi
        else
            log_warn "服务 $service 不存在，跳过"
        fi
    done
}

main() {
    disable_firewall
    disable_selinux
    reset_interfaces
    start_services
    log_success "所有服务已处理完毕"
    log_warn "请手动进入“2.python-reliance”文件夹，手动执行“./install_python_reliance.sh”"
}

main
