#!/bin/bash

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # 恢复默认颜色

# 打印菜单
print_menu() {
    echo -e "${BLUE}请选择操作：${NC}"
    echo -e "${BLUE}1. pxe环境全新安装${NC}"
    echo -e "${BLUE}2. pxe环境依赖安装${NC}"
    echo -e "${BLUE}3. pxe环境参数设置${NC}"
}

# 执行脚本并检查错误
execute_script() {
    local script_name=$1
    echo -e "${BLUE}正在执行 $script_name...${NC}"
    ./$script_name
    local exit_status=$?
    if [ $exit_status -ne 0 ]; then
        echo -e "${RED}$script_name 执行失败，终止后续脚本执行。${NC}"
        exit 1
    fi
    echo -e "${GREEN}$script_name 执行成功！${NC}"
    for i in {5..1}; do
        printf "\r${YELLOW}将在 %d 秒后进行下一步安装...${NC}" "$i"
        sleep 1
    done
    echo
    clear
}

# 获取用户输入
print_menu
read -p "请输入数字 (1/2/3): " choice

case $choice in
    1)
        # pxe环境全新安装
        execute_script "pxe_install.sh"
        execute_script "pxe_net.sh"
        execute_script "pxe_radvd.sh"
        execute_script "pxe_tftp.sh"
        execute_script "pxe_dhcp.sh"
        execute_script "pxe_start_services.sh"
        echo -e "${GREEN}pxe环境全新安装完成！${NC}"
        ;;
    2)
        # pxe环境依赖安装
        execute_script "pxe_install.sh"
        echo -e "${GREEN}pxe环境依赖安装完成！${NC}"
        ;;
    3)
        # pxe环境参数设置
        execute_script "pxe_net.sh"
        execute_script "pxe_radvd.sh"
        execute_script "pxe_tftp.sh"
        execute_script "pxe_dhcp.sh"
        execute_script "pxe_start_services.sh"
        echo -e "${GREEN}pxe环境参数设置完成！${NC}"
        ;;
    *)
        echo -e "${RED}无效的选择，请输入 1、2 或 3。${NC}"
        exit 1
        ;;
esac