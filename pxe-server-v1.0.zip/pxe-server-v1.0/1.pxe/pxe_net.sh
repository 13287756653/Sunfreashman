#!/bin/bash

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
NC='\033[0m' # 恢复默认颜色

# 图形符号
CHECKMARK="✓"
CROSSMARK="✗"
INFO="ℹ️"
WARNING="⚠️"
ARROW="→"

# 分隔线
SEPARATOR="=================================================================="

# 函数：打印带颜色的标题
print_title() {
    echo -e "${BLUE}${SEPARATOR}${NC}"
    echo -e "${BLUE}${1}${NC}"
    echo -e "${BLUE}${SEPARATOR}${NC}"
}

# 函数：打印成功信息
print_success() {
    echo -e "${GREEN}${CHECKMARK} ${1}${NC}"
}

# 函数：打印错误信息
print_error() {
    echo -e "${RED}${CROSSMARK} ${1}${NC}"
}

# 函数：打印提示信息
print_info() {
    echo -e "${YELLOW}${INFO} ${1}${NC}"
}

# 函数：打印警告信息
print_warning() {
    echo -e "${MAGENTA}${WARNING} ${1}${NC}"
}

# 函数：打印带箭头的步骤
print_step() {
    echo -e "${BLUE}${ARROW} ${1}${NC}"
}

# 函数：显示进度动画
show_progress() {
    local msg=$1
    local duration=$2
    local spin_chars="|/-\\"
    local i=0
    echo -ne "${YELLOW}${INFO} ${msg} "
    
    while [ $i -lt $duration ]; do
        local idx=$((i % 4))
        echo -ne "[${spin_chars:$idx:1}]"
        sleep 0.2
        echo -ne "\b\b\b   \b\b\b"
        ((i++))
    done
    
    echo -e "${NC}"
}

# ====== 网络配置脚本开始 ======
print_title "网络接口配置工具"

# 1. 检查并列出可用网口
print_step "扫描可用网络接口"
available_interfaces=$(ip -o link show | grep -v "lo\|vir\|tun\|tap\|bond\|team\|dummy\|docker" | awk -F': ' '{print $2}')

if [ -z "$available_interfaces" ]; then
    print_error "未找到可用的以太网口！！！"
    exit 1
else
    print_success "检测到以下可用以太网口："
    echo -e "${GREEN}  $(echo "$available_interfaces" | tr ' ' '\n' | sort | sed 's/^/  - /')${NC}"
fi

# 2. 删除列出的所有网口的连接配置
print_step "清理旧网络配置"
for interface in $available_interfaces; do
    nmcli connection delete $interface 2>/dev/null
    print_success "已删除网口配置文件：${GREEN}$interface${NC}"
done

# 3. 检查并删除网卡配置文件
print_step "清理旧配置文件"
network_scripts_dir="/etc/sysconfig/network-scripts"
if [ -d "$network_scripts_dir" ]; then
    config_files=$(ls $network_scripts_dir/ifcfg-* 2>/dev/null)
    if [ -n "$config_files" ]; then
        for file in $config_files; do
            interface=$(basename $file | sed 's/ifcfg-//')
            if echo "$available_interfaces" | grep -q $interface; then
                rm $file
                print_success "已清除配置文件：${GREEN}$file${NC}"
            fi
        done
    else
        print_info "没有找到网卡配置文件"
    fi
else
    print_warning "目录 $network_scripts_dir 不存在"
fi

# 4. 创建新的网卡配置文件
print_step "创建新网络配置"
first_interface=$(echo "$available_interfaces" | head -n 1)
nmcli connection add con-name $first_interface ifname $first_interface type ethernet autoconnect yes 2>/dev/null
print_success "新网卡配置已创建：${GREEN}$first_interface${NC}"

# 5. 修改网卡配置文件参数
print_step "配置网络参数"
config_file="/etc/sysconfig/network-scripts/ifcfg-$first_interface"

# 定义配置参数数组
config_params=(
    "BOOTPROTO=static"
    "ONBOOT=yes"
    "IPADDR=192.168.3.10"
    "NETMASK=255.255.255.0"
    "GATEWAY=192.168.3.1"
    "IPV6INIT=yes"
    "IPV6_AUTOCONF=no"
    "IPV6ADDR=2025:db8::10/64"
    "IPV6_DEFAULTGW=2025:db8::1"
)

# 应用配置参数
for param in "${config_params[@]}"; do
    key=$(echo "$param" | cut -d'=' -f1)
    value=$(echo "$param" | cut -d'=' -f2-)
    
    if grep -q "$key=" "$config_file"; then
        sed -i "s/$key=.*$/$param/" "$config_file"
        print_success "已更新参数 ${YELLOW}$key${NC} 为 ${GREEN}$value${NC}"
    else
        echo "$param" >> "$config_file"
        print_success "已添加参数 ${YELLOW}$key${NC}=${GREEN}$value${NC}"
    fi
done

# 6. 重启网络并检查配置
print_step "应用网络配置"
print_info "正在重启网络服务并验证配置..."

max_attempts=5
attempt=1
success_ipv4=false
success_ipv6=false

while [ $attempt -le $max_attempts ]; do
    systemctl restart network
    show_progress "等待网络服务启动 ($attempt/$max_attempts)" 2
    
    assigned_ip=$(ip -4 addr show $first_interface | grep -oP 'inet \K[\d.]+')
    assigned_ipv6=$(ip -6 addr show $first_interface | grep -oP 'inet6 \K[0-9a-fA-F:]+' | grep -v "fe80")
    
    if [ "$assigned_ip" == "192.168.3.10" ]; then
        success_ipv4=true
    fi
    
    if [[ "$assigned_ipv6" == *"2025:db8::10"* ]]; then
        success_ipv6=true
    fi
    
    if $success_ipv4 && $success_ipv6; then
        break
    fi
    
    ((attempt++))
    echo -e "${YELLOW}${INFO} 第 $attempt 次尝试，配置尚未生效，重新尝试...${NC}"
done

# 7. 输出最终结果
print_title "配置结果总结"
if $success_ipv4 && $success_ipv6; then
    print_success "网络配置成功！"
    echo -e "${GREEN}  IPv4 地址: 192.168.3.10/24${NC}"
    echo -e "${GREEN}  IPv4 网关: 192.168.3.1${NC}"
    echo -e "${GREEN}  IPv6 地址: 2025:db8::10/64${NC}"
    echo -e "${GREEN}  IPv6 网关: 2025:db8::1${NC}"
else
    print_error "网络配置失败！"
    if ! $success_ipv4; then
        print_error "IPv4 配置失败，期望地址: 192.168.3.10"
    fi
    if ! $success_ipv6; then
        print_error "IPv6 配置失败，期望地址: 2025:db8::10"
    fi
    
    print_warning "请手动检查网络配置："
    echo -e "  ${YELLOW}1. 查看配置文件: ${NC}cat $config_file"
    echo -e "  ${YELLOW}2. 检查网络服务: ${NC}systemctl status network"
    
    # 美观的倒计时退出
    print_info "脚本将在10秒后自动退出，或按Ctrl+C立即退出"
    for i in {10..1}; do
        echo -ne "${YELLOW}${INFO} 倒计时 ${RED}$i${YELLOW} 秒...${NC}\r"
        sleep 1
    done
    echo -e "\n${RED}${CROSSMARK} 脚本执行结束，配置未生效${NC}"
    exit 1
fi

print_title "网络配置工具执行完成"
