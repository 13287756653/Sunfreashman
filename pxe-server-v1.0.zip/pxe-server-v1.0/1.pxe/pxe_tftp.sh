#!/bin/bash

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # 恢复默认颜色

# 表格分隔线
SEPARATOR="============================================"

# tftp配置文件内容

config_file="/etc/xinetd.d/tftp"
SPACES="        "
sed -i '6,$d' "$config_file"
echo "service tftp" >> $config_file
echo "{" >> $config_file
echo -e "$SPACES socket_type             = dgram" >> "$config_file"
echo -e "$SPACES protocol                = udp" >> "$config_file"
echo -e "$SPACES wait                    = yes" >> "$config_file"
echo -e "$SPACES user                    = root" >> "$config_file"
echo -e "$SPACES server                  = /usr/sbin/in.tftpd" >> "$config_file"
echo -e "$SPACES server_args             = -s /var/lib/tftpboot" >> "$config_file"
echo -e "$SPACES disable                 = no" >> "$config_file"
echo -e "$SPACES per_source              = 11" >> "$config_file"
echo -e "$SPACES cps                     = 100 2" >> "$config_file"
echo -e "$SPACES flags                   = IPv4" >> "$config_file"
echo -e "$SPACES flags                   = IPv6" >> "$config_file"
echo -e "};" >> "$config_file"





# TFTP配置校验脚本
# 用于校验/etc/xinetd.d/tftp文件中的配置是否符合标准

# 标准配置模板（忽略空格）
declare -A STANDARD_CONFIG=(
    ["socket_type"]="dgram"
    ["protocol"]="udp"
    ["wait"]="yes"
    ["user"]="root"
    ["server"]="/usr/sbin/in.tftpd"
    ["server_args"]="-s /var/lib/tftpboot"
    ["disable"]="no"
    ["per_source"]="11"
    ["cps"]="100 2"
    ["flags"]="IPv4 IPv6"  # 合并多个flags行
)

# 配置文件路径
CONFIG_FILE="/etc/xinetd.d/tftp"
# 临时文件
TEMP_FILE="/tmp/tftp_config_temp_$$"
# 错误计数器
ERROR_COUNT=0

# 函数：打印彩色标题
print_title() {
    echo -e "${BLUE}${SEPARATOR}${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}${SEPARATOR}${NC}"
}

# 函数：打印配置项结果
print_config_result() {
    local param=$1
    local file_value=$2
    local std_value=$3
    local stripped_file=$(echo "$file_value" | tr -d '[:space:]')
    local stripped_std=$(echo "$std_value" | tr -d '[:space:]')
    
    if [ "$stripped_file" = "$stripped_std" ]; then
        echo -e "${GREEN}✓${NC} 参数 '$param' 一致"
    else
        ERROR_COUNT=$((ERROR_COUNT + 1))
        echo -e "${RED}✗${NC} 参数 '$param' 不一致"
        echo -e "  ${YELLOW}文件值:${NC} '${file_value:-<未设置>}'"
        echo -e "  ${YELLOW}标准值:${NC} '${std_value}'"
        echo -e "${BLUE}--------------------------------${NC}"
    fi
}

# 检查文件是否存在
if [ ! -f "$CONFIG_FILE" ]; then
    echo -e "${RED}错误: 文件 '$CONFIG_FILE' 不存在${NC}"
    exit 1
fi

# 提取service tftp块内容到临时文件
awk '/^[[:space:]]*service[[:space:]]+tftp[[:space:]]*$/,/^[[:space:]]*}/{print}' "$CONFIG_FILE" > "$TEMP_FILE"

# 检查是否找到配置块
if [ ! -s "$TEMP_FILE" ]; then
    echo -e "${RED}错误: 在文件中未找到 'service tftp' 配置块${NC}"
    rm -f "$TEMP_FILE"
    exit 1
fi

# 打印校验开始信息
print_title "正在校验TFTP配置..."

# 校验每个配置项
for param in "${!STANDARD_CONFIG[@]}"; do
    # 从临时文件中提取参数值
    if [ "$param" = "flags" ]; then
        param_value=$(grep -E "^[[:space:]]*${param}[[:space:]]*=[[:space:]]*" "$TEMP_FILE" | \
                      sed -E "s/^[[:space:]]*${param}[[:space:]]*=[[:space:]]*//" | \
                      tr -d '\n' | tr -s '[:space:]')
    else
        param_value=$(grep -E "^[[:space:]]*${param}[[:space:]]*=[[:space:]]*" "$TEMP_FILE" | \
                      head -1 | \
                      sed -E "s/^[[:space:]]*${param}[[:space:]]*=[[:space:]]*//" | \
                      tr -s '[:space:]')
    fi
    
    # 打印配置项校验结果
    print_config_result "$param" "$param_value" "${STANDARD_CONFIG[$param]}"
done

# 清理临时文件
rm -f "$TEMP_FILE"

# 打印校验总结
print_title "校验结果"
if [ $ERROR_COUNT -eq 0 ]; then
    echo -e "${GREEN}✅ TFTP配置成功! 所有参数均符合标准。${NC}"
    exit 0
else
    echo -e "${RED}❌ TFTP配置存在 $ERROR_COUNT 处不一致!${NC}"
    exit 1
fi    
