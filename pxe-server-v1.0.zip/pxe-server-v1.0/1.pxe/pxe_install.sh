#!/bin/bash

# 定义颜色常量
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # 恢复默认颜色

# 定义需要检查的软件列表
software_list=(dhcp httpd xinetd tftp tftp-server net-tools network-scripts radvd python3-pip)

# 初始化未安装软件列表
missing_software=()

# 检查每个软件是否安装
for software in "${software_list[@]}"; do
    if ! rpm -qa | grep -q "$software"; then
        missing_software+=("$software")
    fi
done

# 输出美化函数
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}|          PXE 软件安装检查器          |${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo
}

# 网络检查函数
check_network() {
    echo -e "${BLUE}正在检查网络连接...${NC}"
    
    # 使用timeout命令限制ping执行时间
    if timeout 10 ping -c 3 -W 3 www.baidu.com &>/dev/null; then
        echo -e "${GREEN}✓ 网络已连通${NC}"
        return 0
    else
        echo -e "${RED}✗ 网络连接失败${NC}"
        return 1
    fi
}

# 显示进度条的函数
show_progress() {
    local pid=$1
    local delay=0.1
    local spinstr='◐◓◑◒'
    local width=50
    local total_packages=${#missing_software[@]}
    local last_percent=0
    local current_percent=0
    local target_percent=0
    local last_update=$(date +%s%N)
    local temp_file=$(mktemp)
    
    # 计算初始进度（0%）
    update_progress 0
    
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        # 尝试从yum输出中提取进度信息
        running=$(grep -c "Running transaction" "$temp_file")
        installing=$(grep -cE '^Installing : ' "$temp_file")
        installed=$(grep -cE '^(Installed|Updated):' "$temp_file")
        
        # 计算目标进度
        if [ $running -gt 0 ]; then
            # 事务执行阶段 (5-95%)
            target_percent=$((5 + 90 * (installing + installed) / (total_packages * 2)))
        else
            # 预处理阶段 (0-5%)
            target_percent=$((5 * (installing + installed) / total_packages))
        fi
        
        # 确保目标进度不超过100%且不后退
        if [ $target_percent -gt 100 ]; then
            target_percent=100
        fi
        if [ $target_percent -lt $last_percent ]; then
            target_percent=$last_percent
        fi
        
        # 当前时间
        current_time=$(date +%s%N)
        # 计算时间差（纳秒转秒）
        time_diff=$(echo "scale=3; ($current_time - $last_update) / 1000000000" | bc)
        
        # 如果目标进度有变化或者超过0.5秒没有更新
        if [ $target_percent -gt $current_percent ] || (( $(echo "$time_diff > 0.5" | bc -l) )); then
            # 平滑过渡：每次增加不超过3%或目标进度的10%
            increment=$(echo "scale=0; ($target_percent - $current_percent) * 0.1" | bc)
            if [ $(echo "$increment < 3" | bc -l) ]; then
                increment=3
            fi
            
            # 计算新的当前进度
            current_percent=$((current_percent + increment))
            if [ $current_percent -gt $target_percent ]; then
                current_percent=$target_percent
            fi
            
            # 更新进度显示
            update_progress $current_percent
            
            # 更新最后更新时间
            last_update=$current_time
            last_percent=$current_percent
        fi
        
        sleep $delay
    done
    
    # 确保进度达到100%
    if [ $current_percent -lt 100 ]; then
        update_progress 100
    fi
    echo # 换行，使结果在下一行显示
    
    # 清理临时文件
    rm -f "$temp_file"
}

# 更新进度显示的函数
update_progress() {
    local percent=$1
    local width=50
    local spinstr='◐◓◑◒'
    
    # 计算进度条长度
    progress=$((width * percent / 100))
    
    # 构建进度条
    bar=""
    for ((i=0; i<progress; i++)); do
        bar+="█"
    done
    for ((i=progress; i<width; i++)); do
        bar+=" "
    done
    
    # 获取旋转指针字符
    spin_char="${spinstr:$(( $(date +%s) % 4 )):1}"
    
    # 显示进度条（使用蓝色表示进行中）
    printf "\r${BLUE}[%-50s] %3d%% %c${NC}" "$bar" "$percent" "$spin_char"
}

# 创建文件夹并赋予权限的函数
create_folders() {
    folders=(
        "/var/www/html/arm"
        "/var/www/html/x86"
        "/var/lib/tftpboot/arm"
        "/var/lib/tftpboot/x86"

    )
    for folder in "${folders[@]}"; do
        if ! mkdir -p "$folder"; then
            echo -e "${RED}✗ 创建 $folder 文件夹失败${NC}"
            return 1
        fi
        if ! chmod 777 "$folder"; then
            echo -e "${RED}✗ 赋予 $folder 文件夹权限失败${NC}"
            return 1
        fi
        echo -e "${GREEN}✓ $folder 文件夹创建并赋予最高权限成功${NC}"
    done
    return 0
}

# 主程序
print_header
if [ ${#missing_software[@]} -eq 0 ]; then
    echo -e "${GREEN}✓ pxe所需软件已全部安装完成！${NC}"
    if create_folders; then
        echo -e "${GREEN}✓ 所有文件夹创建并赋予权限成功！${NC}"
    else
        echo -e "${RED}✗ 文件夹创建或权限设置过程中出现错误${NC}"
    fi
else
    echo -e "${YELLOW}以下软件未安装，需要联网下载所需依赖：${NC}"
    for software in "${missing_software[@]}"; do
        echo -e "  ${RED}✗${NC} $software"
    done
    echo
    
    read -p "是否继续安装？(y/n): " choice
    case "$choice" in
        y|Y)
            read -p "请连接外网后，按 y 开始安装，按其他键取消: " confirm
            if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
                if check_network; then
                    echo -e "${BLUE}开始安装未安装的软件...${NC}"
                    
                    # 创建临时文件记录yum输出
                    temp_file=$(mktemp)
                    
                    # 后台执行安装并将输出重定向到临时文件
                    sudo yum install -y "${missing_software[@]}" > "$temp_file" 2>&1 &
                    yum_pid=$!
                    
                    # 显示进度条
                    show_progress $yum_pid
                    
                    # 等待yum进程结束并获取退出状态
                    wait $yum_pid
                    install_status=$?
                    
                    # 清理临时文件
                    rm -f "$temp_file"
                    
                    # 检查安装状态
                    if [ $install_status -eq 0 ]; then
                        echo -e "${GREEN}✓ 所有软件安装成功！${NC}"
                        if create_folders; then
                            echo -e "${GREEN}✓ 所有文件夹创建并赋予权限成功！${NC}"
                        else
                            echo -e "${RED}✗ 文件夹创建或权限设置过程中出现错误${NC}"
                        fi
                    else
                        echo -e "${RED}✗ 安装过程中出现错误，请检查网络连接或手动安装。${NC}"
                    fi
                else
                    # 网络连接失败，显示倒计时
                    for i in {5..1}; do
                        printf "\r${YELLOW}脚本将在 %d 秒后退出...${NC}" "$i"
                        sleep 1
                    done
                    echo
                    exit 1
                fi
            else
                echo -e "${YELLOW}安装已取消。${NC}"
            fi
            ;;
        n|N)
            echo -e "${YELLOW}操作已终止。${NC}"
            ;;
        *)
            echo -e "${RED}无效的选择，操作已终止。${NC}"
            ;;
    esac
fi
mkdir -p /mnt/iso
mkdir -p /mnt/iso/arm
mkdir -p /mnt/iso/x86