import os

class Config:
    """PXE管理器配置类"""
    
    # 基础配置
    ISO_DIR = os.getenv('PXE_ISO_DIR', '/mnt/iso')
    CACHE_FILE = os.getenv('PXE_CACHE_FILE', '/opt/pxe-manager/iso_cache.json')
    UPLOAD_TMP_DIR = os.getenv('PXE_UPLOAD_TMP_DIR', '/opt/pxe-manager/upload_tmp')
    MOUNT_BASE = os.getenv('PXE_MOUNT_BASE', '/var/www/html')
    LOG_FILE = os.getenv('PXE_LOG_FILE', '/var/log/pxe-manager.log')
    
    # 安全配置
    MAX_FILE_SIZE = 4 * 1024 * 1024 * 1024  # 4GB
    ALLOWED_EXTENSIONS = {'.iso'}
    
    # 服务配置
    HOST = os.getenv('PXE_HOST', '0.0.0.0')
    PORT = int(os.getenv('PXE_PORT', 5000))
    DEBUG = os.getenv('PXE_DEBUG', 'false').lower() == 'true'
    
    # 监控配置
    SYSTEM_METRICS_INTERVAL = int(os.getenv('PXE_SYSTEM_METRICS_INTERVAL', 5))
    LOG_MONITOR_INTERVAL = int(os.getenv('PXE_LOG_MONITOR_INTERVAL', 5))
    
    # 缓存配置
    CACHE_MAX_SIZE = int(os.getenv('PXE_CACHE_MAX_SIZE', 100))
    LOG_CACHE_SIZE = int(os.getenv('PXE_LOG_CACHE_SIZE', 100))
    
    @classmethod
    def validate(cls):
        """验证配置"""
        errors = []
        
        # 检查目录权限
        dirs_to_check = [cls.ISO_DIR, cls.UPLOAD_TMP_DIR, cls.MOUNT_BASE]
        for dir_path in dirs_to_check:
            if not os.path.exists(dir_path):
                try:
                    os.makedirs(dir_path, exist_ok=True)
                except Exception as e:
                    errors.append(f"无法创建目录 {dir_path}: {e}")
        
        # 检查端口范围
        if not (1 <= cls.PORT <= 65535):
            errors.append(f"端口号无效: {cls.PORT}")
        
        return errors 