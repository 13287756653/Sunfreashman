# PXE镜像管理工具

一个现代化的PXE镜像管理工具，提供Web界面进行ISO文件管理、PXE服务控制和系统监控。

## 功能特性

- 🖼️ **镜像管理**: ISO文件上传、下载、删除、MD5校验
- 🔧 **PXE服务控制**: DHCP、TFTP、HTTP等服务管理
- 📊 **系统监控**: 实时CPU、内存、磁盘、网络监控
- 📝 **日志监控**: 多模块日志实时查看
- 🎯 **KS文件生成**: 自动生成Kickstart配置文件
- 🔒 **安全防护**: 路径遍历防护、文件类型验证

## 快速开始

### 环境要求

- Python 3.7+
- Linux系统（支持mount命令）
- 足够的磁盘空间存储ISO文件

### 安装

1. **克隆项目**
```bash
git clone <repository-url>
cd pxe-manager
```

2. **安装依赖**
```bash
pip install -r requirements.txt
```

3. **配置环境变量**（可选）
```bash
export PXE_ISO_DIR=/mnt/iso
export PXE_HOST=0.0.0.0
export PXE_PORT=5000
export PXE_DEBUG=false
```

4. **启动服务**
```bash
python start.py
```

### Docker部署

```bash
# 构建镜像
docker build -t pxe-manager .

# 运行容器
docker run -d \
  --name pxe-manager \
  -p 5000:5000 \
  -v /mnt/iso:/mnt/iso \
  -v /var/www/html:/var/www/html \
  pxe-manager
```

## 配置说明

### 环境变量

| 变量名 | 默认值 | 说明 |
|--------|--------|------|
| PXE_ISO_DIR | /mnt/iso | ISO文件存储目录 |
| PXE_HOST | 0.0.0.0 | 服务监听地址 |
| PXE_PORT | 5000 | 服务端口 |
| PXE_DEBUG | false | 调试模式 |
| PXE_LOG_FILE | /var/log/pxe-manager.log | 日志文件路径 |

### 目录结构

```
pxe-manager/
├── pxe_manager.py      # 主应用文件
├── config.py           # 配置文件
├── start.py            # 启动脚本
├── requirements.txt    # Python依赖
├── templates/          # HTML模板
├── static/            # 静态资源
└── README.md          # 说明文档
```

## API接口

### 健康检查
- `GET /health` - 系统健康状态

### 镜像管理
- `GET /api/iso-list` - 获取镜像列表
- `GET /api/iso-details` - 获取镜像详情
- `POST /api/upload-iso` - 上传镜像
- `POST /api/delete-iso` - 删除镜像

### PXE服务
- `GET /api/pxe-services-status` - 获取服务状态
- `POST /api/service-control` - 控制服务

### 系统监控
- `GET /api/system-metrics` - 获取系统指标
- `GET /api/logs/<module>` - 获取日志

## 安全特性

- ✅ 路径遍历防护
- ✅ 文件类型验证
- ✅ 文件名清理
- ✅ 大小限制
- ✅ 安全日志记录

## 监控告警

- 内存使用率 > 90% 时告警
- 服务异常时记录日志
- 安全事件实时记录

## 故障排除

### 常见问题

1. **权限问题**
```bash
# 确保目录权限正确
sudo chown -R www-data:www-data /mnt/iso
sudo chmod -R 755 /mnt/iso
```

2. **端口占用**
```bash
# 检查端口占用
netstat -tlnp | grep 5000
```

3. **日志查看**
```bash
# 查看应用日志
tail -f /var/log/pxe-manager.log
```

## 开发

### 本地开发

```bash
# 设置开发环境
export PXE_DEBUG=true
export PXE_LOG_FILE=./pxe-manager.log

# 启动开发服务器
python start.py
```

### 测试

```bash
# 健康检查
curl http://localhost:5000/health

# API测试
curl http://localhost:5000/api/iso-list
```

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request！ 