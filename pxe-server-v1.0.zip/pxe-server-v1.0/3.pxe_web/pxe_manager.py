import os
import subprocess
import json
import hashlib
import time
from flask import Flask, render_template, request, jsonify, send_file
from flask_cors import CORS
from datetime import datetime
import threading
import queue
import shutil
import re
import socket
import psutil
import glob
import collections
import logging
import mimetypes
from pathlib import Path
from werkzeug.utils import secure_filename

# 日志监控相关
import subprocess
import time
from collections import deque

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.getenv('PXE_LOG_FILE', '/var/log/pxe-manager.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# 错误处理
@app.errorhandler(413)
def too_large(e):
    return jsonify({'error': '文件太大'}), 413

@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': '页面不存在'}), 404

@app.errorhandler(500)
def internal_error(e):
    logger.error(f"内部服务器错误: {str(e)}")
    return jsonify({'error': '内部服务器错误'}), 500

@app.errorhandler(Exception)
def handle_exception(e):
    logger.error(f"未处理的异常: {str(e)}")
    return jsonify({'error': '服务器错误'}), 500

# 安全配置
app.config['MAX_CONTENT_LENGTH'] = 4 * 1024 * 1024 * 1024  # 4GB
ALLOWED_EXTENSIONS = {'.iso'}
MAX_FILE_SIZE = 4 * 1024 * 1024 * 1024  # 4GB

# 配置
ISO_DIR = os.getenv('PXE_ISO_DIR', '/mnt/iso')
CACHE_FILE = os.getenv('PXE_CACHE_FILE', '/opt/pxe-manager/iso_cache.json')
MD5_QUEUE = queue.Queue()
MD5_RESULTS = {}
MD5_LOCK = threading.Lock()
UPLOAD_TMP_DIR = os.getenv('PXE_UPLOAD_TMP_DIR', '/opt/pxe-manager/upload_tmp')
MOUNT_BASE = os.getenv('PXE_MOUNT_BASE', '/var/www/html')
LOG_FILE = os.getenv('PXE_LOG_FILE', '/var/log/pxe-manager.log')

# 确保缓存目录存在
cache_dir = os.path.dirname(CACHE_FILE)
os.makedirs(cache_dir, exist_ok=True)
os.makedirs(UPLOAD_TMP_DIR, exist_ok=True)

# 安全验证函数
def is_safe_path(path, base_path):
    """验证路径是否安全，防止路径遍历攻击"""
    try:
        path = os.path.abspath(path)
        base_path = os.path.abspath(base_path)
        return path.startswith(base_path)
    except Exception:
        return False

def is_allowed_file(filename):
    """检查文件扩展名是否允许"""
    if not filename:
        return False
    file_ext = Path(filename).suffix.lower()
    return file_ext in ALLOWED_EXTENSIONS

def validate_file_size(file_size):
    """验证文件大小"""
    return file_size <= MAX_FILE_SIZE

def sanitize_filename(filename):
    """清理文件名，移除危险字符"""
    return secure_filename(filename)

def log_security_event(event_type, details):
    """记录安全事件"""
    logger.warning(f"SECURITY_EVENT: {event_type} - {details}")

# 系统资源监控数据存储
SYSTEM_METRICS = collections.deque(maxlen=60)  # 存储最近60个数据点（5分钟）
SYSTEM_METRICS_LOCK = threading.Lock()

# 网络流量统计
NETWORK_STATS = {}
NETWORK_STATS_LOCK = threading.Lock()

# 日志缓存，每个模块最多保存100条日志
log_cache = {
    'dhcp': deque(maxlen=100),
    'tftp': deque(maxlen=100),
    'xinetd': deque(maxlen=100),
    'radvd': deque(maxlen=100),
    'httpd': deque(maxlen=100),
    'audit': deque(maxlen=100)
}

# 清理无效缓存
def clean_invalid_cache(cache):
    valid_cache = {}
    total_entries = len(cache)
    removed_entries = 0
    
    for key, data in cache.items():
        file_path = data.get('path')
        if not file_path or not os.path.exists(file_path):
            removed_entries += 1
            continue
            
        # 检查文件修改时间
        current_mtime = os.path.getmtime(file_path)
        cached_mtime = datetime.strptime(data.get('last_modified'), '%Y-%m-%d %H:%M:%S').timestamp()
        
        if current_mtime != cached_mtime:
            removed_entries += 1
            continue
            
        valid_cache[key] = data
    
    print(f"缓存清理完成: 总条目 {total_entries}, 移除无效条目 {removed_entries}, 有效条目 {len(valid_cache)}")
    return valid_cache

# 加载缓存
def load_cache():
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, 'r') as f:
                cache = json.load(f)
                # 清理无效缓存
                return clean_invalid_cache(cache)
        except Exception as e:
            print(f"加载缓存失败: {e}")
    return {}

# 保存缓存
def save_cache(cache):
    try:
        with open(CACHE_FILE, 'w') as f:
            json.dump(cache, f, indent=2)
    except Exception as e:
        print(f"保存缓存失败: {e}")

# 计算文件MD5
def calculate_md5(file_path):
    hash_md5 = hashlib.md5()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    except Exception as e:
        print(f"计算MD5失败: {e}")
        return "无法计算"

# MD5计算工作线程
def md5_worker():
    while True:
        task = MD5_QUEUE.get()
        if task is None:
            break
            
        arch, filename, cache_key, file_path = task
        
        try:
            # 计算MD5
            md5_hash = calculate_md5(file_path)
            
            # 更新结果
            with MD5_LOCK:
                MD5_RESULTS[cache_key] = md5_hash
                
                # 更新缓存
                cache = load_cache()
                if cache_key in cache:
                    cache[cache_key]['md5'] = md5_hash
                    save_cache(cache)
                    
            print(f"MD5计算完成: {filename}")
        except Exception as e:
            print(f"MD5计算错误: {e}")
        finally:
            MD5_QUEUE.task_done()

# 启动MD5工作线程
md5_thread = threading.Thread(target=md5_worker, daemon=True)
md5_thread.start()

def get_disk_io_bytes():
    def parse_diskstats():
        stats = {}
        with open('/proc/diskstats') as f:
            for line in f:
                parts = line.split()
                if len(parts) < 14: continue
                dev = parts[2]
                # 过滤掉loop、ram等非物理磁盘
                if dev.startswith('loop') or dev.startswith('ram') or dev.startswith('fd'):
                    continue
                stats[dev] = (int(parts[5]), int(parts[9]))  # 读扇区数, 写扇区数
        return stats
    sector_size = 512  # 绝大多数Linux默认512字节
    s1 = parse_diskstats()
    time.sleep(1)
    s2 = parse_diskstats()
    read_bytes = sum((s2[d][0] - s1[d][0]) * sector_size for d in s1 if d in s2)
    write_bytes = sum((s2[d][1] - s1[d][1]) * sector_size for d in s1 if d in s2)
    return read_bytes, write_bytes

# 获取系统资源信息
def get_system_metrics():
    try:
        # 1. CPU/内存
        cpu_percent = 0.0
        memory_percent = 0.0
        try:
            top_out = subprocess.check_output("top -b -n 1", shell=True, text=True)
            for line in top_out.splitlines():
                if 'Cpu(s):' in line:
                    # 兼容多语言top输出
                    m = re.search(r'([0-9.]+)\s*id', line)
                    if m:
                        idle = float(m.group(1))
                        cpu_percent = 100.0 - idle
                if 'Mem :' in line or 'MiB Mem :' in line or 'KiB Mem :' in line or 'Mem:' in line:
                    # 兼容多语言top输出
                    m = re.findall(r'([0-9.]+)[a-zA-Z]*\s*total,\s*([0-9.]+)[a-zA-Z]*\s*free,\s*([0-9.]+)[a-zA-Z]*\s*used', line)
                    if m:
                        total, free, used = map(float, m[0])
                        memory_percent = used / total * 100 if total > 0 else 0
        except Exception as e:
            print(f"top采集失败: {e}")

        # 2. 磁盘读写速率（/proc/diskstats）
        try:
            disk_read_bps, disk_write_bps = get_disk_io_bytes()
        except Exception as e:
            print(f"/proc/diskstats采集失败: {e}")
            disk_read_bps, disk_write_bps = 0, 0

        # 3. 网络流量（ip -s link）
        network_bytes_sent = 0
        network_bytes_recv = 0
        try:
            ip_out = subprocess.check_output("ip -s link", shell=True, text=True)
            lines = ip_out.splitlines()
            for i, line in enumerate(lines):
                if re.match(r'\d+: ', line):
                    # 设备名行
                    if i+3 < len(lines):
                        rx = lines[i+3].strip().split()
                        tx = lines[i+5].strip().split() if i+5 < len(lines) else None
                        if rx and len(rx) >= 1:
                            network_bytes_recv += int(rx[0])
                        if tx and len(tx) >= 1:
                            network_bytes_sent += int(tx[0])
        except Exception as e:
            print(f"ip -s link采集失败: {e}")

        return {
            'timestamp': datetime.now().isoformat(),
            'cpu_percent': cpu_percent,
            'memory_percent': memory_percent,
            'disk_read_bytes': disk_read_bps,
            'disk_write_bytes': disk_write_bps,
            'network_bytes_sent': network_bytes_sent,
            'network_bytes_recv': network_bytes_recv,
            'network_interfaces': {}  # 可选:详细接口
        }
    except Exception as e:
        print(f"获取系统资源信息失败: {e}")
        return None

# 计算网络流量速度
def calculate_network_speed(current_stats, previous_stats):
    if not previous_stats:
        return {'bytes_sent_speed': 0, 'bytes_recv_speed': 0}
    
    time_diff = 5  # 5秒间隔
    bytes_sent_diff = current_stats['network_bytes_sent'] - previous_stats['network_bytes_sent']
    bytes_recv_diff = current_stats['network_bytes_recv'] - previous_stats['network_bytes_recv']
    
    return {
        'bytes_sent_speed': bytes_sent_diff / time_diff,  # bytes/s
        'bytes_recv_speed': bytes_recv_diff / time_diff   # bytes/s
    }

# 系统资源监控工作线程
def system_monitor_worker():
    previous_stats = None
    while True:
        try:
            current_stats = get_system_metrics()
            if current_stats:
                # 计算网络速度
                network_speed = calculate_network_speed(current_stats, previous_stats)
                current_stats.update(network_speed)
                
                # 存储数据
                with SYSTEM_METRICS_LOCK:
                    SYSTEM_METRICS.append(current_stats)
                
                previous_stats = current_stats
            
            time.sleep(5)  # 每5秒更新一次
        except Exception as e:
            print(f"系统监控错误: {e}")
            time.sleep(5)

# 启动系统监控线程
system_monitor_thread = threading.Thread(target=system_monitor_worker, daemon=True)
system_monitor_thread.start()

# 检测架构类型
def detect_architecture(filename):
    arch_types = ["x86_64", "amd64", "i386", "arm64", "aarch64", "armhf"]
    filename_lower = filename.lower()
    
    for arch in arch_types:
        if arch in filename_lower:
            return arch
    
    return "N/A"

# 获取镜像信息
def get_iso_details(arch, filename):
    file_path = os.path.join(ISO_DIR, arch, filename)
    
    # 检查文件是否存在
    if not os.path.exists(file_path):
        return {"error": f"文件不存在: {file_path}"}
    
    # 获取文件大小（GB）
    size_bytes = os.path.getsize(file_path)
    size_gb = round(size_bytes / (1024 ** 3), 2)
    
    # 获取最后修改时间
    modified_time = os.path.getmtime(file_path)
    modified_date = datetime.fromtimestamp(modified_time).strftime('%Y-%m-%d %H:%M:%S')
    
    # 检测架构类型（从文件名中提取）
    architecture = detect_architecture(filename)
    
    # 初始化缓存
    cache = load_cache()
    cache = clean_invalid_cache(cache)  # 每次都清理一次
    cache_key = f"{arch}_{filename}"
    
    # 检查缓存
    cached_data = cache.get(cache_key)
    if cached_data:
        # 验证缓存的有效性
        cached_path = cached_data.get('path')
        cached_mtime = datetime.strptime(cached_data.get('last_modified'), '%Y-%m-%d %H:%M:%S').timestamp()
        
        if cached_path == file_path and cached_mtime == modified_time:
            print(f"使用缓存数据: {filename}")
            
            # 检查MD5状态
            with MD5_LOCK:
                if cache_key in MD5_RESULTS:
                    # 使用最新计算的MD5
                    cached_data['md5'] = MD5_RESULTS[cache_key]
                elif cached_data['md5'] == "正在校验中...":
                    # 检查是否有未完成的MD5计算任务
                    if cache_key not in MD5_RESULTS:
                        # 添加到队列进行计算
                        MD5_QUEUE.put((arch, filename, cache_key, file_path))
                        
            return cached_data
    
    # 构建详情数据
    details = {
        "name": filename,
        "architecture": architecture,
        "path": file_path,
        "size": f"{size_gb} GB",
        "md5": "正在校验中...",  # 初始状态显示正在校验
        "last_modified": modified_date
    }
    
    # 更新缓存
    cache[cache_key] = details
    save_cache(cache)
    
    # 添加到MD5计算队列
    MD5_QUEUE.put((arch, filename, cache_key, file_path))
    
    return details

# 获取ISO列表
@app.route('/api/iso-list')
def get_iso_list():
    iso_list = {}
    
    try:
        # 检查ISO目录是否存在
        if not os.path.exists(ISO_DIR):
            return jsonify({"error": f"ISO目录不存在: {ISO_DIR}"}), 404
        
        # 获取所有架构目录
        arch_dirs = [d for d in os.listdir(ISO_DIR) if os.path.isdir(os.path.join(ISO_DIR, d))]
        
        # 遍历每个架构目录
        for arch in arch_dirs:
            arch_path = os.path.join(ISO_DIR, arch)
            # 获取ISO文件列表
            iso_files = [f for f in os.listdir(arch_path) if f.lower().endswith('.iso')]
            
            if iso_files:
                iso_list[arch] = iso_files
    
    except Exception as e:
        return jsonify({"error": f"获取ISO列表失败: {str(e)}"}), 500
    
    return jsonify(iso_list)

# 获取ISO详情
@app.route('/api/iso-details')
def get_details():
    arch = request.args.get('arch')
    filename = request.args.get('filename')
    
    if not arch or not filename:
        return jsonify({"error": "缺少必要参数"}), 400
    
    details = get_iso_details(arch, filename)
    
    if "error" in details:
        return jsonify(details), 404
    
    return jsonify(details)

# 检查MD5状态
@app.route('/api/check-md5')
def check_md5():
    arch = request.args.get('arch')
    filename = request.args.get('filename')
    
    if not arch or not filename:
        return jsonify({"error": "缺少必要参数"}), 400
    
    cache_key = f"{arch}_{filename}"
    
    with MD5_LOCK:
        if cache_key in MD5_RESULTS:
            return jsonify({"md5": MD5_RESULTS[cache_key]})
    
    return jsonify({"md5": "正在校验中..."})

# 下载ISO文件
@app.route('/download/<path:file_path>')
def download_iso(file_path):
    try:
        # 安全检查：确保文件在ISO目录内
        if not is_safe_path(file_path, ISO_DIR):
            log_security_event("PATH_TRAVERSAL_ATTEMPT", f"Attempted access to: {file_path}")
            return jsonify({"error": "非法访问"}), 403
        
        if not os.path.exists(file_path) or not os.path.isfile(file_path):
            return jsonify({"error": "文件不存在"}), 404
        
        # 检查文件类型
        if not is_allowed_file(file_path):
            log_security_event("INVALID_FILE_TYPE", f"Attempted download of: {file_path}")
            return jsonify({"error": "不支持的文件类型"}), 400
        
        return send_file(file_path, as_attachment=True)
    except Exception as e:
        logger.error(f"下载文件失败: {file_path}, 错误: {str(e)}")
        return jsonify({"error": "下载失败"}), 500

@app.route('/api/arch-list')
def arch_list():
    try:
        if not os.path.exists(ISO_DIR):
            return jsonify([])
        arch_dirs = [d for d in os.listdir(ISO_DIR) if os.path.isdir(os.path.join(ISO_DIR, d))]
        return jsonify(arch_dirs)
    except Exception as e:
        return jsonify([]), 500

@app.route('/api/upload-iso', methods=['POST'])
def upload_iso():
    try:
        arch = request.form.get('arch')
        filename = request.form.get('filename')
        chunk_index = int(request.form.get('chunkIndex', 0))
        total_chunks = int(request.form.get('totalChunks', 1))
        file = request.files.get('file')

        if not arch or not filename or file is None:
            return jsonify({'error': '参数不完整'}), 400

        # 安全验证
        if not is_allowed_file(filename):
            log_security_event("INVALID_UPLOAD_TYPE", f"Attempted upload: {filename}")
            return jsonify({'error': '不支持的文件类型'}), 400

        # 清理文件名
        safe_filename = sanitize_filename(filename)
        if safe_filename != filename:
            log_security_event("FILENAME_SANITIZED", f"Original: {filename}, Sanitized: {safe_filename}")

        # 验证架构目录
        if not re.match(r'^[a-zA-Z0-9_-]+$', arch):
            log_security_event("INVALID_ARCH", f"Invalid architecture: {arch}")
            return jsonify({'error': '无效的架构名称'}), 400

        arch_dir = os.path.join(ISO_DIR, arch)
        os.makedirs(arch_dir, exist_ok=True)
        tmp_dir = os.path.join(UPLOAD_TMP_DIR, f"{arch}_{safe_filename}")
        os.makedirs(tmp_dir, exist_ok=True)

        chunk_path = os.path.join(tmp_dir, f"chunk_{chunk_index}")
        file.save(chunk_path)

        # 检查是否所有分片都上传完毕
        uploaded_chunks = len([f for f in os.listdir(tmp_dir) if f.startswith('chunk_')])
        if uploaded_chunks == total_chunks:
            # 合并分片
            final_path = os.path.join(arch_dir, safe_filename)
            with open(final_path, 'wb') as outfile:
                for i in range(total_chunks):
                    chunk_file = os.path.join(tmp_dir, f"chunk_{i}")
                    with open(chunk_file, 'rb') as infile:
                        outfile.write(infile.read())
            # 清理临时分片
            for f in os.listdir(tmp_dir):
                os.remove(os.path.join(tmp_dir, f))
            os.rmdir(tmp_dir)
            logger.info(f"文件上传完成: {safe_filename}")
            return jsonify({'success': True, 'merged': True})

        return jsonify({'success': True, 'merged': False})
    except Exception as e:
        logger.error(f"文件上传失败: {str(e)}")
        return jsonify({'error': '上传失败'}), 500

@app.route('/api/upload-status', methods=['GET'])
def upload_status():
    arch = request.args.get('arch')
    filename = request.args.get('filename')
    total_chunks = int(request.args.get('totalChunks', 1))
    tmp_dir = os.path.join(UPLOAD_TMP_DIR, f"{arch}_{filename}")
    uploaded = []
    if os.path.exists(tmp_dir):
        for i in range(total_chunks):
            if os.path.exists(os.path.join(tmp_dir, f"chunk_{i}")):
                uploaded.append(i)
    return jsonify({'uploaded': uploaded})

@app.route('/api/upload-cancel', methods=['POST'])
def upload_cancel():
    arch = request.form.get('arch')
    filename = request.form.get('filename')
    tmp_dir = os.path.join(UPLOAD_TMP_DIR, f"{arch}_{filename}")
    if os.path.exists(tmp_dir):
        for f in os.listdir(tmp_dir):
            os.remove(os.path.join(tmp_dir, f))
        os.rmdir(tmp_dir)
    return jsonify({'success': True})

@app.route('/api/delete-iso', methods=['POST'])
def delete_iso():
    data = request.get_json()
    arch = data.get('arch')
    filename = data.get('filename')
    if not arch or not filename:
        return jsonify({'error': '参数不完整'}), 400
    file_path = os.path.join(ISO_DIR, arch, filename)
    if not os.path.exists(file_path):
        return jsonify({'error': '文件不存在'}), 404
    try:
        # 使用 rm -rf 删除文件
        result = subprocess.run(['rm', '-rf', file_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode != 0:
            return jsonify({'error': f'删除失败: {result.stderr.decode()}'}), 500
        # 可选：删除缓存
        cache_key = f"{arch}_{filename}"
        cache = load_cache()
        if cache_key in cache:
            del cache[cache_key]
            save_cache(cache)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': f'删除失败: {str(e)}'}), 500

def get_mount_point(arch, mount_dir):
    return os.path.join(MOUNT_BASE, arch, mount_dir)

def ensure_dir_exists(path):
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)
        # 赋予权限（如有需要可调整权限）
        try:
            os.chmod(path, 0o755)
        except Exception as e:
            print(f"设置权限失败: {e}")

# 查询ISO挂载状态
@app.route('/api/mount-status')
def mount_status():
    arch = request.args.get('arch')
    filename = request.args.get('filename')
    if not arch or not filename:
        return jsonify({'error': '参数不完整'}), 400
    iso_path = os.path.join(ISO_DIR, arch, filename)
    try:
        # 解析mount命令输出
        result = subprocess.run(['mount'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        mounts = result.stdout.splitlines()
        for line in mounts:
            if iso_path in line:
                # 解析挂载点
                parts = line.split()
                if len(parts) >= 3:
                    return jsonify({'mounted': True, 'mount_point': parts[2]})
        return jsonify({'mounted': False})
    except Exception as e:
        return jsonify({'error': f'查询挂载状态失败: {str(e)}'}), 500

# 列出挂载目录
@app.route('/api/list-mount-dirs')
def list_mount_dirs():
    arch = request.args.get('arch')
    if not arch:
        return jsonify({'error': '缺少arch参数'}), 400
    arch_dir = os.path.join(MOUNT_BASE, arch)
    ensure_dir_exists(arch_dir)
    try:
        dirs = [d for d in os.listdir(arch_dir) if os.path.isdir(os.path.join(arch_dir, d))]
        return jsonify({'dirs': dirs})
    except Exception as e:
        return jsonify({'error': f'列出目录失败: {str(e)}'}), 500

# 创建挂载目录
@app.route('/api/create-mount-dir', methods=['POST'])
def create_mount_dir():
    data = request.get_json()
    arch = data.get('arch')
    mount_dir = data.get('mount_dir')
    if not arch or not mount_dir:
        return jsonify({'error': '参数不完整'}), 400
    arch_dir = os.path.join(MOUNT_BASE, arch)
    ensure_dir_exists(arch_dir)
    target_dir = os.path.join(arch_dir, mount_dir)
    try:
        if not os.path.exists(target_dir):
            os.makedirs(target_dir, exist_ok=True)
            os.chmod(target_dir, 0o755)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': f'创建目录失败: {str(e)}'}), 500

# 挂载ISO
@app.route('/api/mount-iso', methods=['POST'])
def mount_iso():
    data = request.get_json()
    arch = data.get('arch')
    filename = data.get('filename')
    mount_dir = data.get('mount_dir')
    if not arch or not filename or not mount_dir:
        return jsonify({'error': '参数不完整'}), 400
    iso_path = os.path.join(ISO_DIR, arch, filename)
    mount_point = get_mount_point(arch, mount_dir)
    ensure_dir_exists(mount_point)
    try:
        # 检查是否已挂载
        result = subprocess.run(['mount'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if iso_path in result.stdout:
            return jsonify({'error': '该ISO已挂载'}), 400
        # 执行挂载
        mount_cmd = ['mount', '-o', 'loop', iso_path, mount_point]
        result = subprocess.run(mount_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode != 0:
            return jsonify({'error': f'挂载失败: {result.stderr}'}), 500
        return jsonify({'success': True, 'mount_point': mount_point})
    except Exception as e:
        return jsonify({'error': f'挂载失败: {str(e)}'}), 500

# 卸载ISO
@app.route('/api/umount-iso', methods=['POST'])
def umount_iso():
    data = request.get_json()
    arch = data.get('arch')
    filename = data.get('filename')
    mount_dir = data.get('mount_dir')
    if not arch or not filename or not mount_dir:
        return jsonify({'error': '参数不完整'}), 400
    iso_path = os.path.join(ISO_DIR, arch, filename)
    mount_point = get_mount_point(arch, mount_dir)
    try:
        # 检查是否已挂载
        result = subprocess.run(['mount'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        found = False
        for line in result.stdout.splitlines():
            if iso_path in line and mount_point in line:
                found = True
                break
        if not found:
            return jsonify({'error': '未检测到挂载'}), 400
        # 执行卸载
        umount_cmd = ['umount', mount_point]
        result = subprocess.run(umount_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode != 0:
            return jsonify({'error': f'卸载失败: {result.stderr}'}), 500
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': f'卸载失败: {str(e)}'}), 500

@app.route('/api/generate-ks', methods=['POST'])
def generate_ks():
    data = request.get_json()
    arch = data.get('arch')
    mount_dir = data.get('mount_dir')
    filename = data.get('filename')
    url = data.get('url')
    mode = data.get('mode', 'graphical')
    finish = data.get('finish', 'reboot')
    autopart = data.get('autopart', False)
    disk = data.get('disk', '')
    hostname = data.get('hostname', 'localhost.localdomain')
    rootpw = data.get('rootpw', '')
    ks_content = data.get('ks_content')

    # 校验文件名
    if not filename or not re.match(r'^[\w\-]+\.cfg$', filename):
        return jsonify({'error': '文件名不合法'}), 400
    if not arch or not mount_dir:
        return jsonify({'error': '参数不完整'}), 400

    ks_dir = os.path.join(MOUNT_BASE, arch, 'ks', mount_dir)
    os.makedirs(ks_dir, exist_ok=True)
    ks_path = os.path.join(ks_dir, filename)

    # 新增：如果有自定义ks_content，直接写入
    if ks_content is not None:
        try:
            with open(ks_path, 'w', encoding='utf-8') as f:
                f.write(ks_content)
            return jsonify({'success': True})
        except Exception as e:
            import traceback
            print('写入KS文件失败:', ks_path)
            print(traceback.format_exc())
            return jsonify({'error': f'写入KS文件失败: {str(e)}', 'path': ks_path}), 500

    # 兼容老逻辑：无ks_content时用模板生成
    template_path = os.path.join(os.path.dirname(__file__), 'ks.txt')
    if not os.path.exists(template_path):
        return jsonify({'error': 'ks.txt模板不存在'}), 500
    with open(template_path, 'r', encoding='utf-8') as f:
        ks_template = f.read()

    ks_content = ks_template
    ks_content = re.sub(r'url --url=.*', f'url --url={url}', ks_content)
    ks_content = re.sub(r'^(graphical|text)', mode, ks_content, flags=re.MULTILINE)
    ks_content = re.sub(r'^(reboot|poweroff|halt)', finish, ks_content, flags=re.MULTILINE)
    ks_content = re.sub(r'network  --hostname=.*', f'network  --hostname={hostname}', ks_content)
    if autopart and disk:
        ks_content = re.sub(r'ignoredisk --only-use=.*', f'ignoredisk --only-use={disk}', ks_content)
        ks_content = re.sub(r'clearpart --all  --initlabel --drives=/dev/.*', f'clearpart --all  --initlabel --drives=/dev/{disk}', ks_content)
        if 'autopart' not in ks_content:
            ks_content = ks_content.replace('ignoredisk', 'autopart\nignoredisk', 1)
    else:
        ks_content = re.sub(r'^(ignoredisk --only-use=.*)', r'#\1', ks_content, flags=re.MULTILINE)
        ks_content = re.sub(r'^(autopart)', r'#\1', ks_content, flags=re.MULTILINE)
        ks_content = re.sub(r'^(clearpart --all  --initlabel --drives=/dev/.*)', r'#\1', ks_content, flags=re.MULTILINE)
    if rootpw:
        ks_content = re.sub(r'rootpw --plaintext .*', f'rootpw --plaintext {rootpw}', ks_content)
    else:
        ks_content = re.sub(r'rootpw --plaintext .*', '#rootpw --plaintext    #未设置', ks_content)

    try:
        with open(ks_path, 'w', encoding='utf-8') as f:
            f.write(ks_content)
        return jsonify({'success': True})
    except Exception as e:
        import traceback
        print('写入KS文件失败:', ks_path)
        print(traceback.format_exc())
        return jsonify({'error': f'写入KS文件失败: {str(e)}', 'path': ks_path}), 500

@app.route('/api/generate-ks-preview', methods=['POST'])
def generate_ks_preview():
    data = request.get_json()
    arch = data.get('arch')
    mount_dir = data.get('mount_dir')
    filename = data.get('filename')
    url = data.get('url')
    mode = data.get('mode', 'graphical')
    finish = data.get('finish', 'reboot')
    autopart = data.get('autopart', False)
    disk = data.get('disk', '')
    hostname = data.get('hostname', 'localhost.localdomain')
    rootpw = data.get('rootpw', '')

    # 校验文件名
    if not filename or not re.match(r'^[\w\-]+\.cfg$', filename):
        return jsonify({'error': '文件名不合法'}), 400
    if not arch or not mount_dir:
        return jsonify({'error': '参数不完整'}), 400

    template_path = os.path.join(os.path.dirname(__file__), 'ks.txt')
    if not os.path.exists(template_path):
        return jsonify({'error': 'ks.txt模板不存在'}), 500
    with open(template_path, 'r', encoding='utf-8') as f:
        ks_template = f.read()

    ks_content = ks_template
    ks_content = re.sub(r'url --url=.*', f'url --url={url}', ks_content)
    ks_content = re.sub(r'^(graphical|text)', mode, ks_content, flags=re.MULTILINE)
    ks_content = re.sub(r'^(reboot|poweroff|halt)', finish, ks_content, flags=re.MULTILINE)
    ks_content = re.sub(r'network  --hostname=.*', f'network  --hostname={hostname}', ks_content)
    if autopart and disk:
        ks_content = re.sub(r'ignoredisk --only-use=.*', f'ignoredisk --only-use={disk}', ks_content)
        ks_content = re.sub(r'clearpart --all  --initlabel --drives=/dev/.*', f'clearpart --all  --initlabel --drives=/dev/{disk}', ks_content)
        if 'autopart' not in ks_content:
            ks_content = ks_content.replace('ignoredisk', 'autopart\nignoredisk', 1)
    else:
        ks_content = re.sub(r'^(ignoredisk --only-use=.*)', r'#\1', ks_content, flags=re.MULTILINE)
        ks_content = re.sub(r'^(autopart)', r'#\1', ks_content, flags=re.MULTILINE)
        ks_content = re.sub(r'^(clearpart --all  --initlabel --drives=/dev/.*)', r'#\1', ks_content, flags=re.MULTILINE)
    if rootpw:
        ks_content = re.sub(r'rootpw --plaintext .*', f'rootpw --plaintext {rootpw}', ks_content)
    else:
        ks_content = re.sub(r'rootpw --plaintext .*', '#rootpw --plaintext    #未设置', ks_content)

    return jsonify({'success': True, 'ks_content': ks_content})

@app.route('/api/server-ips')
def server_ips():
    ipv4_list = []
    ipv6_list = []
    try:
        addrs = psutil.net_if_addrs()
        for iface, infos in addrs.items():
            if iface.startswith('lo') or iface.startswith('docker') or iface.startswith('veth') or iface.startswith('br-') or iface.startswith('virbr'):
                continue
            for info in infos:
                if info.family == socket.AF_INET:
                    ip = info.address
                    if ip and not ip.startswith('127.') and ip != '0.0.0.0':
                        ipv4_list.append(ip)
                elif info.family == socket.AF_INET6:
                    ip = info.address.split('%')[0]
                    if ip and not ip.startswith('fe80') and ip != '::1':
                        ipv6_list.append(ip)
        return jsonify({'ipv4': ipv4_list, 'ipv6': ipv6_list})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ipv4-pxe', methods=['POST'])
def ipv4_pxe():
    data = request.get_json()
    arch = data.get('arch')
    mount_dir = data.get('mount_dir')
    iso_name = data.get('iso_name')
    ipv4 = data.get('ipv4')
    if not arch or not mount_dir or not iso_name or not ipv4:
        return jsonify({'success': False, 'error': '参数不完整'}), 400
    try:
        # 路径定义
        src_pxeboot = os.path.join(MOUNT_BASE, arch, mount_dir, 'images', 'pxeboot')
        src_efi = os.path.join(MOUNT_BASE, arch, mount_dir, 'EFI', 'BOOT')
        tftp_iso_dir = os.path.join('/var/lib/tftpboot', arch, mount_dir)
        tftp_arch_dir = os.path.join('/var/lib/tftpboot', arch)
        os.makedirs(tftp_iso_dir, exist_ok=True)
        os.makedirs(tftp_arch_dir, exist_ok=True)
        os.chmod(tftp_iso_dir, 0o755)
        os.chmod(tftp_arch_dir, 0o755)
        # 1. 复制initrd.img和vmlinuz
        for fname in ['initrd.img', 'vmlinuz']:
            src = os.path.join(src_pxeboot, fname)
            dst = os.path.join(tftp_iso_dir, fname)
            if not os.path.exists(src):
                return jsonify({'success': False, 'error': f'找不到{src}'}), 400
            shutil.copy2(src, dst)
            os.chmod(dst, 0o644)
        # 2. 复制EFI/BOOT下所有文件到/var/lib/tftpboot/{arch}/
        if not os.path.exists(src_efi):
            return jsonify({'success': False, 'error': f'找不到{src_efi}'}), 400
        for f in glob.glob(os.path.join(src_efi, '*')):
            if os.path.isfile(f):
                shutil.copy2(f, tftp_arch_dir)
        # 3. 清理grub.cfg
        grub_cfg = os.path.join(tftp_arch_dir, 'grub.cfg')
        if not os.path.exists(grub_cfg):
            # 若不存在则创建空文件
            with open(grub_cfg, 'w') as f:
                pass
        # 读取并清理内容
        with open(grub_cfg, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        new_lines = []
        found = False
        for line in lines:
            if '### END /etc/grub.d/00_header ###' in line:
                new_lines.append(line)
                found = True
                break
            new_lines.append(line)
        # 只保留END及以上内容
        if found:
            pass  # new_lines已处理
        else:
            new_lines = lines  # 没有END标记则保留全部
        # 4. 追加menuentry
        menuentry = f"""menuentry 'Install {iso_name}' --class red --class gnu-linux --class gnu --class os {{
        set root=(tftp,{ipv4})
	linux {arch}/{mount_dir}/vmlinuz inst.geoloc=0 rd.iscsi.waitnet=0 inst.ks=http://{ipv4}/{arch}/ks/{mount_dir}/{mount_dir}.cfg ip=dhcp inst.repo=http://{ipv4}/{arch}/{mount_dir} loglevel=8 console=tty0
	initrd {arch}/{mount_dir}/initrd.img
}}
"""
        # 5. 检查权限和写入
        try:
            with open(grub_cfg, 'w', encoding='utf-8') as f:
                for l in new_lines:
                    f.write(l)
                if not new_lines or not new_lines[-1].endswith('\n'):
                    f.write('\n')
                f.write(menuentry)
        except Exception as e:
            return jsonify({'success': False, 'error': f'写入grub.cfg失败: {str(e)}'}), 500
        # 6. 读取最新grub.cfg内容返回
        with open(grub_cfg, 'r', encoding='utf-8') as f:
            grub_content = f.read()
        # 7. 重启服务
        services = ['dhcpd', 'tftp', 'httpd', 'xinetd']
        restart_results = {}
        for svc in services:
            try:
                result = subprocess.run(['systemctl', 'restart', svc], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if result.returncode == 0:
                    restart_results[svc] = 'success'
                else:
                    restart_results[svc] = f'fail: {result.stderr.strip()}'
            except Exception as e:
                restart_results[svc] = f'fail: {str(e)}'
        return jsonify({'success': True, 'grub_content': grub_content, 'restart': restart_results})
    except Exception as e:
        import traceback
        return jsonify({'success': False, 'error': str(e), 'trace': traceback.format_exc()}), 500

@app.route('/api/update-grub', methods=['POST'])
def update_grub():
    data = request.get_json()
    arch = data.get('arch')
    grub_content = data.get('grub_content')
    if not arch or grub_content is None:
        return jsonify({'success': False, 'error': '参数不完整'}), 400
    grub_cfg = os.path.join('/var/lib/tftpboot', arch, 'grub.cfg')
    try:
        with open(grub_cfg, 'w', encoding='utf-8') as f:
            f.write(grub_content)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/ipv6-pxe', methods=['POST'])
def ipv6_pxe():
    data = request.get_json()
    arch = data.get('arch')
    mount_dir = data.get('mount_dir')
    iso_name = data.get('iso_name')
    # IPv6地址写死
    ipv6 = '2025:db8::10'
    if not arch or not mount_dir or not iso_name:
        return jsonify({'success': False, 'error': '参数不完整'}), 400
    try:
        src_pxeboot = os.path.join(MOUNT_BASE, arch, mount_dir, 'images', 'pxeboot')
        src_efi = os.path.join(MOUNT_BASE, arch, mount_dir, 'EFI', 'BOOT')
        tftp_iso_dir = os.path.join('/var/lib/tftpboot', arch, mount_dir)
        tftp_arch_dir = os.path.join('/var/lib/tftpboot', arch)
        os.makedirs(tftp_iso_dir, exist_ok=True)
        os.makedirs(tftp_arch_dir, exist_ok=True)
        os.chmod(tftp_iso_dir, 0o755)
        os.chmod(tftp_arch_dir, 0o755)
        # 1. 复制initrd.img和vmlinuz
        for fname in ['initrd.img', 'vmlinuz']:
            src = os.path.join(src_pxeboot, fname)
            dst = os.path.join(tftp_iso_dir, fname)
            if not os.path.exists(src):
                return jsonify({'success': False, 'error': f'找不到{src}'}), 400
            shutil.copy2(src, dst)
            os.chmod(dst, 0o644)
        # 2. 复制EFI/BOOT下所有文件到/var/lib/tftpboot/{arch}/
        if not os.path.exists(src_efi):
            return jsonify({'success': False, 'error': f'找不到{src_efi}'}), 400
        for f in glob.glob(os.path.join(src_efi, '*')):
            if os.path.isfile(f):
                shutil.copy2(f, tftp_arch_dir)
        # 3. 清理grub.cfg
        grub_cfg = os.path.join(tftp_arch_dir, 'grub.cfg')
        if not os.path.exists(grub_cfg):
            with open(grub_cfg, 'w') as f:
                pass
        with open(grub_cfg, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        new_lines = []
        found = False
        for line in lines:
            if '### END /etc/grub.d/00_header ###' in line:
                new_lines.append(line)
                found = True
                break
            new_lines.append(line)
        if found:
            pass
        else:
            new_lines = lines
        # 4. 追加menuentry
        menuentry = f"""menuentry 'Install {iso_name}' --class red --class gnu-linux --class gnu --class os {{
        set root=(tftp,[{ipv6}])
	linux {arch}/{mount_dir}/vmlinuz inst.geoloc=0 rd.iscsi.waitnet=0 inst.ks=http://[{ipv6}]/{arch}/ks/{mount_dir}/{mount_dir}.cfg ip=dhcp inst.repo=http://[{ipv6}]/{arch}/{mount_dir} loglevel=8 console=tty0
	initrd {arch}/{mount_dir}/initrd.img
}}
"""
        try:
            with open(grub_cfg, 'w', encoding='utf-8') as f:
                for l in new_lines:
                    f.write(l)
                if not new_lines or not new_lines[-1].endswith('\n'):
                    f.write('\n')
                f.write(menuentry)
        except Exception as e:
            return jsonify({'success': False, 'error': f'写入grub.cfg失败: {str(e)}'}), 500
        with open(grub_cfg, 'r', encoding='utf-8') as f:
            grub_content = f.read()
        # 5. 修改/etc/dhcp/dhcpd6.conf
        dhcpd6_conf = '/etc/dhcp/dhcpd6.conf'
        bootfile = 'grubx64.efi' if arch.startswith('x86') or arch == 'amd64' else 'grubaa64.efi'
        bootfile_url = f'option dhcp6.bootfile-url "tftp://[{ipv6}]/{arch}/{bootfile}";'
        try:
            # 读取原文件内容
            if os.path.exists(dhcpd6_conf):
                with open(dhcpd6_conf, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
            else:
                lines = []
            new_lines = []
            found = False
            for line in lines:
                if line.strip().startswith('option dhcp6.bootfile-url'):
                    new_lines.append(bootfile_url + '\n')
                    found = True
                else:
                    new_lines.append(line)
            if not found:
                new_lines.append(bootfile_url + '\n')
            with open(dhcpd6_conf, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)
        except Exception as e:
            return jsonify({'success': False, 'error': f'写入dhcpd6.conf失败: {str(e)}'}), 500
        # 6. 重启服务
        services = ['dhcpd6', 'tftp', 'httpd', 'xinetd', 'radvd']
        restart_results = {}
        for svc in services:
            try:
                result = subprocess.run(['systemctl', 'restart', svc], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if result.returncode == 0:
                    restart_results[svc] = 'success'
                else:
                    restart_results[svc] = f'fail: {result.stderr.strip()}'
            except Exception as e:
                restart_results[svc] = f'fail: {str(e)}'
        return jsonify({'success': True, 'grub_content': grub_content, 'restart': restart_results})
    except Exception as e:
        import traceback
        return jsonify({'success': False, 'error': str(e), 'trace': traceback.format_exc()}), 500

@app.route('/api/clear-pxe', methods=['POST'])
def clear_pxe():
    import glob
    try:
        # 1. 卸载所有挂载的镜像
        try:
            result = subprocess.run(['mount'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            mounts = result.stdout.splitlines()
            umount_targets = []
            for line in mounts:
                # 只处理/var/www/html下的挂载点
                parts = line.split()
                if len(parts) >= 3 and parts[2].startswith(MOUNT_BASE):
                    umount_targets.append(parts[2])
            for mp in umount_targets:
                subprocess.run(['umount', mp], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception as e:
            return jsonify({'success': False, 'error': f'卸载镜像失败: {str(e)}'}), 500
        # 2. 删除/var/lib/tftpboot下所有文件夹和文件
        tftp_dir = '/var/lib/tftpboot'
        for f in glob.glob(os.path.join(tftp_dir, '*')):
            try:
                if os.path.isdir(f):
                    shutil.rmtree(f)
                else:
                    os.remove(f)
            except Exception as e:
                pass  # 忽略单个文件/文件夹删除失败
        # 3. 删除/var/www/html下所有文件夹和文件
        html_dir = MOUNT_BASE
        for f in glob.glob(os.path.join(html_dir, '*')):
            try:
                if os.path.isdir(f):
                    shutil.rmtree(f)
                else:
                    os.remove(f)
            except Exception as e:
                pass
        # 4. 停止所有相关服务
        services = ['dhcpd', 'dhcpd6', 'xinetd', 'tftp', 'httpd', 'radvd']
        stop_results = {}
        for svc in services:
            try:
                result = subprocess.run(['systemctl', 'stop', svc], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if result.returncode == 0:
                    stop_results[svc] = 'stopped'
                else:
                    stop_results[svc] = f'fail: {result.stderr.strip()}'
            except Exception as e:
                stop_results[svc] = f'fail: {str(e)}'
        return jsonify({'success': True, 'stopped': stop_results})
    except Exception as e:
        import traceback
        return jsonify({'success': False, 'error': str(e), 'trace': traceback.format_exc()}), 500

@app.route('/api/pxe-services-status')
def pxe_services_status():
    services = ['dhcpd', 'dhcpd6', 'xinetd', 'tftp', 'httpd', 'radvd']
    statuses = {}
    for svc in services:
        try:
            result = subprocess.run(['systemctl', 'is-active', svc], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            status = result.stdout.strip()
            if status == 'active':
                statuses[svc] = {'status': 'active'}
            elif status == 'inactive':
                statuses[svc] = {'status': 'inactive'}
            elif status == 'failed':
                statuses[svc] = {'status': 'failed'}
            else:
                statuses[svc] = {'status': status or 'unknown'}
        except Exception as e:
            statuses[svc] = {'status': 'unknown', 'error': str(e)}
    return jsonify({'success': True, 'statuses': statuses})

@app.route('/api/service-control', methods=['POST'])
def service_control():
    data = request.get_json()
    svc = data.get('service')
    action = data.get('action')
    if svc not in ['dhcpd', 'dhcpd6', 'xinetd', 'tftp', 'httpd', 'radvd']:
        return jsonify({'success': False, 'error': '不支持的服务'}), 400
    if action not in ['start', 'stop', 'restart', 'status']:
        return jsonify({'success': False, 'error': '不支持的操作'}), 400
    try:
        result = subprocess.run(['systemctl', action, svc], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'error': result.stderr.strip()})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# 获取系统资源监控数据
@app.route('/api/system-metrics')
def get_system_metrics_api():
    try:
        with SYSTEM_METRICS_LOCK:
            metrics_list = list(SYSTEM_METRICS)
        
        if not metrics_list:
            # 如果没有历史数据，获取当前数据
            current_metrics = get_system_metrics()
            if current_metrics:
                metrics_list = [current_metrics]
        
        # 格式化数据用于图表显示
        formatted_data = {
            'timestamps': [],
            'cpu_percent': [],
            'memory_percent': [],
            'disk_read_speed': [],
            'disk_write_speed': [],
            'network_sent_speed': [],
            'network_recv_speed': []
        }
        
        for metric in metrics_list:
            formatted_data['timestamps'].append(metric['timestamp'])
            formatted_data['cpu_percent'].append(metric['cpu_percent'])
            formatted_data['memory_percent'].append(metric['memory_percent'])
            
            # 磁盘读写速度（MB/s）
            disk_read_mb = metric.get('disk_read_bytes', 0) / (1024 * 1024)
            disk_write_mb = metric.get('disk_write_bytes', 0) / (1024 * 1024)
            formatted_data['disk_read_speed'].append(round(disk_read_mb, 2))
            formatted_data['disk_write_speed'].append(round(disk_write_mb, 2))
            
            # 网络速度（MB/s）
            network_sent_mb = metric.get('bytes_sent_speed', 0) / (1024 * 1024)
            network_recv_mb = metric.get('bytes_recv_speed', 0) / (1024 * 1024)
            formatted_data['network_sent_speed'].append(round(network_sent_mb, 2))
            formatted_data['network_recv_speed'].append(round(network_recv_mb, 2))
        
        return jsonify({
            'success': True,
            'data': formatted_data,
            'current': metrics_list[-1] if metrics_list else None
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# 主页
@app.route('/')
def index():
    return render_template('index.html')

# 日志监控相关
def get_log_entries(module):
    """获取指定模块的日志条目"""
    try:
        if module == 'dhcp':
            # 监控DHCP相关日志
            cmd = "grep -i 'dhcp' /var/log/messages | tail -50"
        elif module == 'tftp':
            # 监控TFTP相关日志
            cmd = "grep -i 'tftp' /var/log/messages | tail -50"
        elif module == 'xinetd':
            # 监控xinetd相关日志
            cmd = "grep -i 'xinetd' /var/log/messages | tail -50"
        elif module == 'radvd':
            # 监控radvd相关日志
            cmd = "grep -i 'radvd' /var/log/messages | tail -50"
        elif module == 'httpd':
            # 监控HTTP访问日志
            cmd = "tail -50 /var/log/httpd/access_log"
        elif module == 'audit':
            # 监控审计日志和防火墙日志
            cmd = "grep -E '(audit|firewall|iptables)' /var/log/audit/audit.log /var/log/messages | tail -50"
        else:
            return []
        
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            return [line for line in lines if line.strip()]
        else:
            return []
    except Exception as e:
        print(f"Error getting logs for {module}: {e}")
        return []

def update_log_cache():
    """更新所有模块的日志缓存"""
    for module in log_cache.keys():
        try:
            entries = get_log_entries(module)
            # 清空旧缓存
            log_cache[module].clear()
            # 添加新日志条目
            for entry in entries:
                log_cache[module].append({
                    'timestamp': time.time(),
                    'message': entry,
                    'module': module
                })
        except Exception as e:
            print(f"Error updating log cache for {module}: {e}")

@app.route('/api/logs/<module>')
def get_logs(module):
    """获取指定模块的日志"""
    try:
        if module not in log_cache:
            return jsonify({'error': 'Invalid module'}), 400
        
        # 更新日志缓存
        update_log_cache()
        
        # 返回日志数据
        logs = list(log_cache[module])
        return jsonify({
            'module': module,
            'logs': logs,
            'count': len(logs)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/logs/all')
def get_all_logs():
    """获取所有模块的日志"""
    try:
        # 更新所有模块的日志缓存
        update_log_cache()
        
        result = {}
        for module in log_cache.keys():
            result[module] = {
                'logs': list(log_cache[module]),
                'count': len(log_cache[module])
            }
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 启动日志监控线程
def log_monitor_worker():
    """日志监控工作线程"""
    while True:
        try:
            update_log_cache()
            time.sleep(5)  # 每5秒更新一次日志缓存
        except Exception as e:
            print(f"Error in log monitor worker: {e}")
            time.sleep(10)  # 出错时等待更长时间

# 健康检查接口
@app.route('/health')
def health_check():
    """健康检查接口"""
    try:
        # 检查关键目录
        dirs_to_check = [ISO_DIR, UPLOAD_TMP_DIR, MOUNT_BASE]
        for dir_path in dirs_to_check:
            if not os.path.exists(dir_path):
                return jsonify({
                    'status': 'unhealthy',
                    'error': f'目录不存在: {dir_path}'
                }), 500
        
        # 检查系统资源
        memory = psutil.virtual_memory()
        if memory.percent > 90:
            return jsonify({
                'status': 'warning',
                'message': f'内存使用率过高: {memory.percent}%'
            }), 200
        
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'version': '1.0.0'
        }), 200
    except Exception as e:
        logger.error(f"健康检查失败: {str(e)}")
        return jsonify({
            'status': 'unhealthy',
            'error': str(e)
        }), 500

if __name__ == '__main__':
    # 启动时加载并清理缓存
    cache = load_cache()
    print(f"已加载缓存，包含 {len(cache)} 个条目")
    
    # 启动MD5检查线程
    md5_thread = threading.Thread(target=md5_worker, daemon=True)
    md5_thread.start()
    
    # 启动系统监控线程
    system_monitor_thread = threading.Thread(target=system_monitor_worker, daemon=True)
    system_monitor_thread.start()
    
    # 启动日志监控线程
    log_monitor_thread = threading.Thread(target=log_monitor_worker, daemon=True)
    log_monitor_thread.start()
    
    logger.info("PXE管理器启动完成")
    app.run(host='0.0.0.0', port=5000, debug=False)
