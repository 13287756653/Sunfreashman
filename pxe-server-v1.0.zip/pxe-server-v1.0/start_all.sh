#!/bin/bash

set -e  # 只要有一步出错就终止脚本

echo "==== 1. 进入 1.pxe 并运行 setup.sh ===="
cd 1.pxe
bash setup.sh
cd ..

echo "==== 2. 进入 2.python-reliance 并运行 install.sh ===="
cd 2.python-reliance
bash install.sh
cd ..

echo "==== 3. 进入 3.pxe_web 并运行 pxe_manager.py ===="
cd 3.pxe_web
python3 pxe_manager.py
